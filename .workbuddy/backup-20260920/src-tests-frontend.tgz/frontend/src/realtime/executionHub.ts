import { onMounted, onUnmounted } from "vue";
import { HubConnectionBuilder, type HubConnection } from "@microsoft/signalr";
import { useAuthStore } from "../stores/auth";
import { useRealtimeStore } from "../stores/realtime";
import type { EquipmentOccupancyDto, EquipmentDto, ExecutionEvent } from "../api/types";

export function occupancyFromEvent(evt: ExecutionEvent | undefined | null): EquipmentOccupancyDto[] | null {
  if (!evt || evt.type !== "occupancy" || !Array.isArray(evt.payload))
    return null;
  return evt.payload as EquipmentOccupancyDto[];
}

export function applyOccupancyToEquipment(items: EquipmentDto[], rows: EquipmentOccupancyDto[]): EquipmentDto[] {
  const byId = new Map(rows.map((r) => [r.equipmentId, r]));
  return items.map((e) => {
    const occ = byId.get(e.id);
    if (!occ) return { ...e, occupancy: "Idle", occupyingBatchNo: null, occupyingBatchId: null };
    return {
      ...e,
      occupancy: occ.occupancy,
      occupyingBatchNo: occ.batchNo ?? null,
      occupyingBatchId: occ.batchId ?? null
    };
  });
}

export function useExecutionHub(options: {
  onExecution?: (evt: ExecutionEvent) => void;
  subscribeDashboard?: boolean;
}) {
  const auth = useAuthStore();
  const rt = useRealtimeStore();
  let conn: HubConnection | null = null;
  /** 防止 onclose 与 onUnmounted 重复扣减连接数。 */
  let counted = false;

  function release() {
    if (!counted) return;
    counted = false;
    rt.detached();
  }

  onMounted(async () => {
    conn = new HubConnectionBuilder()
      .withUrl(`/hubs/execution?access_token=${auth.token}`)
      .withAutomaticReconnect()
      .build();
    conn.on("execution", (evt: ExecutionEvent) => {
      rt.markEvent();
      options.onExecution?.(evt);
    });
    // 自动重连期间必须让用户看得见：否则页面靠 4 秒轮询"看起来仍在刷新"，
    // 实际上执行事件推送已经断了。
    conn.onreconnecting(() => rt.reconnecting());
    conn.onreconnected(() => rt.reconnected());
    conn.onclose(release);
    try {
      await conn.start();
      counted = true;
      rt.attached();
      if (options.subscribeDashboard !== false)
        await conn.invoke("SubscribeDashboard");
    } catch {
      // 原先 start() 失败是一个未处理的 rejection，界面完全无感知。
      rt.failed();
    }
  });

  onUnmounted(() => {
    release();
    void conn?.stop();
  });
}
