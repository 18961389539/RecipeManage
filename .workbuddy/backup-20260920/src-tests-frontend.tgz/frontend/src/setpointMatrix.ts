export interface MatrixParameter {
  name: string;
  engineeringUnit: string;
  setpoint: number;
  min?: number | null;
  max?: number | null;
  archiveAsQuality?: boolean;
  slotIndex?: number;
}

export interface MatrixStep<T extends MatrixParameter = MatrixParameter> {
  id: string;
  code: string;
  name: string;
  ordinal: number;
  parameters: T[];
}

export interface MatrixColumn {
  id: string;
  label: string;
  title: string;
}

export interface MatrixRow<T extends MatrixParameter = MatrixParameter> {
  key: string;
  name: string;
  unit: string;
  cells: Record<string, T | null>;
}

export interface SetpointMatrixModel<T extends MatrixParameter = MatrixParameter> {
  columns: MatrixColumn[];
  rows: MatrixRow<T>[];
}

export function buildSetpointMatrix<T extends MatrixParameter>(
  steps: MatrixStep<T>[]
): SetpointMatrixModel<T> {
  const ordered = [...steps].sort((a, b) => a.ordinal - b.ordinal);
  const names: { key: string; name: string; unit: string }[] = [];
  const seen = new Set<string>();
  for (const step of ordered) {
    for (const p of step.parameters) {
      const key = `${p.name}|${p.engineeringUnit}`;
      if (seen.has(key)) continue;
      seen.add(key);
      names.push({ key, name: p.name, unit: p.engineeringUnit });
    }
  }
  return {
    columns: ordered.map((s) => ({ id: s.id, label: s.code, title: s.name })),
    rows: names.map((n) => ({
      key: n.key,
      name: n.name,
      unit: n.unit,
      cells: Object.fromEntries(
        ordered.map((s) => [
          s.id,
          s.parameters.find((p) => p.name === n.name && p.engineeringUnit === n.unit) ?? null
        ])
      ) as Record<string, T | null>
    }))
  };
}

export function snapshotToMatrixSteps<T extends MatrixParameter>(
  steps: Array<{
    stepId: string;
    code: string;
    name: string;
    ordinal: number;
    parameters: T[];
  }>
): MatrixStep<T>[] {
  return steps.map((s) => ({
    id: s.stepId,
    code: s.code,
    name: s.name,
    ordinal: s.ordinal,
    parameters: s.parameters
  }));
}

export function formatSetpointSpec(param: MatrixParameter | null | undefined): string {
  if (!param) return "—";
  if (param.min == null && param.max == null) return String(param.setpoint);
  return `${param.setpoint}（${param.min ?? "—"}~${param.max ?? "—"}）`;
}

export interface MeasuredCell {
  value: number;
  oos: boolean;
}

/** stepId → 参数名 → 实测值。原先缺失此导出，导致 vue-tsc 报 TS2305/TS2304。 */
export type MeasuredByStep = Record<string, Record<string, MeasuredCell>>;

export function measuredFromExecutions(
  steps: Array<{ id?: string; stepId?: string; parameters: MatrixParameter[] }>,
  executions: Array<{ stepId: string; qualityJson?: string | null; outcome?: string | null }>
): MeasuredByStep {
  const byId = new Map(steps.map((s) => [s.stepId ?? s.id ?? "", s]));
  const out: MeasuredByStep = {};
  for (const exec of executions) {
    if (exec.outcome === "Skipped" || exec.outcome === "Faulted") continue;
    const raw = exec.qualityJson?.trim();
    if (!raw?.startsWith("{")) continue;
    try {
      const parsed = JSON.parse(raw) as Record<string, unknown>;
      const snap = byId.get(exec.stepId);
      const cells: Record<string, MeasuredCell> = {};
      for (const [tag, value] of Object.entries(parsed)) {
        if (tag.startsWith("PLC:")) continue;
        const numeric = typeof value === "number" ? value : Number(value);
        if (!Number.isFinite(numeric)) continue;
        const param = snap?.parameters.find((p) => p.name === tag);
        if (param && param.archiveAsQuality === false) continue;
        const oos = !!param && (
          (param.min != null && numeric < param.min) ||
          (param.max != null && numeric > param.max)
        );
        cells[tag] = { value: numeric, oos };
      }
      if (Object.keys(cells).length) out[exec.stepId] = cells;
    } catch {
      /* ignore malformed archive */
    }
  }
  return out;
}

/** Keys `${stepId}|${name}|${unit}` for cells whose setpoint/spec changed vs another version. */
export function changedMatrixKeys(
  steps: MatrixStep[],
  diff: { changes?: Array<{ path: string }> } | null | undefined
): Set<string> {
  const keys = new Set<string>();
  if (!diff?.changes?.length) return keys;
  const byCode = new Map(steps.map((s) => [s.code, s]));
  const re = /^([^.]+)\.parameters\[(\d+)\]/;
  for (const change of diff.changes) {
    const m = re.exec(change.path);
    if (!m) continue;
    const step = byCode.get(m[1]);
    if (!step) continue;
    const slot = Number(m[2]);
    const param = step.parameters.find((p) => p.slotIndex === slot) ?? step.parameters[slot];
    if (!param) continue;
    keys.add(`${step.id}|${param.name}|${param.engineeringUnit}`);
  }
  return keys;
}
