<template>
  <div>
    <div class="page-title"><h2>操作审计</h2></div>
    <el-alert type="info" show-icon :closable="false" title="配方提交/审核、批次启停故障、设备点表变更均写入审计。按实体筛选可还原一次闭环。" style="margin-bottom:12px" />
    <el-form inline>
      <el-form-item label="实体">
        <el-select v-model="entityType" clearable placeholder="全部" style="width:180px">
          <el-option label="主配方" value="MasterRecipe" />
          <el-option label="生产批次" value="ProductionBatch" />
          <el-option label="设备" value="EquipmentLine" />
        </el-select>
      </el-form-item>
      <el-form-item><el-button type="primary" :loading="loading" @click="load">刷新</el-button></el-form-item>
    </el-form>
    <el-alert
      v-if="error"
      :closable="false"
      type="error"
      :title="`审计记录加载失败：${error}`"
      show-icon
      style="margin-bottom:12px"
    />
    <el-table :data="items" size="small" v-loading="loading" empty-text="暂无符合条件的审计记录">
      <el-table-column prop="at" label="时间" width="200" fixed>
        <template #default="{ row }">{{ formatDateTime(row.at) }}</template>
      </el-table-column>
      <el-table-column prop="userName" label="用户" width="120" />
      <el-table-column prop="action" label="动作" width="180" />
      <el-table-column prop="entityType" label="实体" width="150">
        <template #default="{ row }">{{ auditEntityLabel(row.entityType) }}</template>
      </el-table-column>
      <el-table-column prop="detail" label="详情" />
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from "vue";
import http from "../../api/http";
import type { AuditLogDto } from "../../api/types";
import { auditEntityLabel } from "../../utils/labels";
import { formatDateTime } from "../../utils/format";
import { useLoad } from "../../utils/useLoad";

const items = ref<AuditLogDto[]>([]);
const entityType = ref("");
const { loading, error, run } = useLoad();

async function load() {
  const params: Record<string, string> = { take: "200" };
  if (entityType.value) params.entityType = entityType.value;
  await run(http.get<AuditLogDto[]>("/audit", { params }), (d) => (items.value = d));
}

onMounted(load);
</script>
