<template>
  <div class="login">
    <el-card class="card">
      <h2>工艺配方管理与实时执行系统</h2>
      <p>离散制造 Batch Recipe Management & Execution</p>
      <el-form @submit.prevent="onSubmit" label-position="top">
        <el-form-item label="用户名">
          <el-input v-model="userName" autocomplete="username" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="password" type="password" autocomplete="current-password" show-password />
        </el-form-item>
        <el-button type="primary" native-type="submit" :loading="loading" style="width:100%">登录</el-button>
      </el-form>
      <div class="roles">
        <el-button v-for="a in accounts" :key="a.user" size="small" text @click="pick(a)">{{ a.label }}</el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import { useAuthStore } from "../stores/auth";

const accounts = [
  { user: "admin", pass: "Admin@123", label: "管理员" },
  { user: "engineer", pass: "Engineer@123", label: "工艺工程师" },
  { user: "supervisor", pass: "Supervisor@123", label: "工艺主管" },
  { user: "qa", pass: "Quality@123", label: "质量工程师" },
  { user: "operator", pass: "Operator@123", label: "车间操作员" }
];

const userName = ref("admin");
const password = ref("Admin@123");
const loading = ref(false);
const auth = useAuthStore();
const route = useRoute();
const router = useRouter();

/**
 * 会话过期被踢回登录页时，路由守卫会带上 redirect（见 main.ts / router）。
 * 只接受站内绝对路径：//evil.com 也是浏览器眼里的"绝对 URL"，必须挡掉。
 */
function redirectTarget(): string {
  const raw = route.query.redirect;
  if (typeof raw !== "string") return "/dashboard";
  return raw.startsWith("/") && !raw.startsWith("//") ? raw : "/dashboard";
}

function pick(a: (typeof accounts)[number]) {
  userName.value = a.user;
  password.value = a.pass;
}

async function onSubmit() {
  loading.value = true;
  try {
    await auth.login(userName.value, password.value);
    await router.replace(redirectTarget());
  } catch (e) {
    ElMessage.error((e as Error).message);
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
/* 窄屏下 420px 固定卡宽会顶出视口（手机上右侧被裁一条），改为随视口收缩并留边距 */
.login { height: 100%; display: grid; place-items: center; padding: 20px 16px; box-sizing: border-box; background: radial-gradient(circle at top, var(--tint), var(--bg)); }
.card { width: min(420px, 100%); background: var(--panel); border: 1px solid var(--line); }
h2 { margin: 0 0 6px; }
p { color: var(--muted); margin: 0 0 18px; }
.roles { margin-top: 14px; display: flex; flex-wrap: wrap; gap: 4px; }
</style>
