<template>
  <!-- 原先根节点是 v-if="batch"：详情取数失败会留下整页空白且无任何提示。 -->
  <div v-if="error || (!batch && loading)" style="padding:8px 0 16px">
    <el-alert
      v-if="error"
      type="error"
      show-icon
      :closable="false"
      :title="`批次详情加载失败：${error}`"
      description="请确认该批次是否存在，或返回批次列表重试。"
    />
    <el-skeleton v-else :rows="8" animated />
  </div>
  <div v-if="batch">
    <div class="page-title">
      <div>
        <h2>{{ batch.batchNo }} · {{ batch.snapshot.recipeName }} v{{ batch.snapshot.versionNumber }}</h2>
        <span>{{ batch.equipmentName }} · {{ batchStatusLabel(batch.status) }} · {{ handshakeSummary }}{{ livePlcLabel }} · 快照 {{ integrityLabel }}{{ scaleLabel }}</span>
      </div>
      <div>
        <el-button v-if="canConfirm && batch.status === 'Running' && awaitingConfirm" type="primary" :loading="busyAction === 'confirm'" @click="confirmStep">人工确认</el-button>
        <el-button v-if="canOperate && (batch.status === 'Created' || batch.status === 'Faulted')" type="primary" :loading="busyAction === 'start'" @click="start">{{ batch.status === 'Faulted' ? '故障后重新排队' : '启动执行' }}</el-button>
        <el-button v-if="canOperate && (batch.status === 'Running' || batch.status === 'Queued')" :loading="busyAction === 'hold'" @click="hold">保持</el-button>
        <el-button v-if="canResume && batch.status === 'Held'" type="primary" :loading="busyAction === 'resume'" @click="resume">恢复执行</el-button>
        <el-button v-if="canSkip && (batch.status === 'Held' || batch.status === 'Faulted' || (batch.status === 'Running' && skipReady))" :loading="busyAction === 'skip'" @click="skip">跳过当前工步</el-button>
        <el-button v-if="canOperate && (batch.status === 'Running' || batch.status === 'Queued' || batch.status === 'Held')" type="danger" :loading="busyAction === 'abort'" @click="abort">中止</el-button>
        <el-button @click="$router.push(`/batches/${batch.id}/record`)">电子批记录</el-button>
      </div>
    </div>
    <el-alert
      v-if="batch.status === 'Completed'"
      :closable="false"
      type="warning"
      show-icon
      title="工艺执行与四步握手已完成。请质量在电子批记录对照归档质检后电子签名放行。"
      style="margin-bottom:12px"
    />
    <el-alert
      v-if="batch.status === 'Released'"
      :closable="false"
      type="success"
      show-icon
      :title="`质量已放行${batch.releasedBy ? ` · ${batch.releasedBy}` : ''}${batch.releaseComment ? ` · ${batch.releaseComment}` : ''}`"
      style="margin-bottom:12px"
    />
    <el-alert
      v-if="batch.status === 'DispositionRejected'"
      :closable="false"
      type="error"
      show-icon
      :title="`质量拒收${batch.releaseComment ? ` · ${batch.releaseComment}` : ''}`"
      style="margin-bottom:12px"
    />

    <div class="handshake-grid">
      <div class="handshake-card" :class="cardClass('A')"><b>A 写参</b><div>PLC_Ready 后写入 Step_ID / Params，回读一致后再置 Trigger_Write</div></div>
      <div class="handshake-card" :class="cardClass('B')"><b>B 应答</b><div>等待 Step_Running，禁止盲写下一步</div></div>
      <div class="handshake-card" :class="cardClass('C')"><b>C 看门狗</b><div>心跳与执行超时监控{{ remainingSeconds != null ? ` · 剩余 ${remainingSeconds.toFixed(0)}s` : "" }}（Step_Running 显示工艺时长）</div></div>
      <div class="handshake-card" :class="cardClass('D')"><b>D 归档步进</b><div>Step_Complete 后读实测、复位、下一步；超差则 QualityOos 保持</div></div>
    </div>

    <el-card style="margin-top:12px" header="控制配方快照 · 工艺画布（冻结拓扑，禁止盲写）">
      <p class="muted" style="margin:0 0 8px">与设计态同一套 Vue Flow 节点。坐标按快照 Procedure/Edges 自动排布（不写入完整性哈希）。点击工步可筛选质检。</p>
      <ProcedureFlow
        flow-id="batch-monitor-flow"
        :steps="flowSteps"
        :edges="flowEdges"
        :outcomes="flowOutcomes"
        :current-step-id="batch.currentStepId"
        :selected-step-id="pickedStep"
        :height="300"
        @select="pickedStep = $event"
      />
    </el-card>

    <el-card style="margin-top:12px" header="冻结 Setpoints 矩阵（Control Recipe Snapshot · 设定 vs 归档实测）">
      <p class="muted" style="margin:0 0 8px">批次创建时从生效主配方冻结，执行中禁止改写。工步完成握手步骤 D 后，单元格显示归档实测并对照规格判定超差。</p>
      <SetpointMatrix
        :steps="matrixSteps"
        :selected-id="pickedStep"
        :current-step-id="batch.currentStepId"
        :measured="measured"
        readonly
        :max-height="280"
        @select="pickedStep = $event"
      />
    </el-card>

    <el-card style="margin-top:12px" header="PLC 写参计划（与调度引擎同源 · 拓扑顺序）">
      <p class="muted" style="margin:0 0 8px">启动前即可核对 Step_ID / Params。Wait、人工确认、质检工步禁止写 PLC；写参工步仅在 PLC_Ready 后下发并回读。</p>
      <PlcWritePlan :items="batch.writePlan ?? []" :current-step-id="batch.currentStepId" />
    </el-card>

    <el-row :gutter="12" style="margin-top:12px">
      <el-col :span="8" :xs="24">
        <el-card header="ISA-88 工步（按 Unit Procedure）">
          <div v-for="group in unitGroups" :key="group.name" class="up-group">
            <div class="up-title">{{ group.name }}{{ unitEquipmentLabel(group.name) }}</div>
            <el-timeline>
              <el-timeline-item v-for="s in group.steps" :key="s.stepId" :type="timelineType(s.stepId)">
                <div class="step-line" @click="pickedStep = s.stepId">
                  {{ s.code }} {{ s.name }} · {{ stepOutcomeLabel(outcome(s.stepId)) }}
                  <div class="muted">{{ s.operation || s.type }}</div>
                </div>
              </el-timeline-item>
            </el-timeline>
          </div>
          <el-divider />
          <div v-if="qualityRows.length">
            <b>工步归档质检</b>
            <el-table :data="qualityRows" size="small" style="margin-top:8px">
              <el-table-column prop="step" label="工步" width="70" fixed />
              <el-table-column prop="tag" label="测点" />
              <el-table-column prop="value" label="实测" />
              <el-table-column prop="spec" label="规格" width="90">
                <template #default="{ row }">
                  <span :style="{ color: row.oos ? 'var(--err)' : 'var(--ok)' }">{{ row.spec }}</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div v-else class="muted">完成握手步骤 D 后，此处显示该工步归档实测。点击时间线工步可筛选。</div>
        </el-card>
      </el-col>
      <el-col :span="8" :xs="24">
        <el-card
          v-for="lane in displayLanes"
          :key="lane.equipmentCode"
          :class="{ 'lane-card': true, selected: selectedLaneCode === lane.equipmentCode }"
          style="margin-bottom:10px"
          @click="selectLane(lane.equipmentCode)"
        >
          <template #header>
            <div class="trend-head">
              <span>PLC 握手位 · {{ lane.equipmentCode }}</span>
              <span class="muted"><HelpTip :term="handshakePhaseLabel(lane.phase)">{{ handshakePhaseLabel(lane.phase) }}</HelpTip></span>
            </div>
          </template>
          <div class="muted" style="margin-bottom:8px">{{ lane.unitProcedure }} · {{ lane.stepCode }} · {{ lane.outcome }}</div>
          <div class="signal"><span>PLC_Ready</span><i class="dot" :class="{ on: signalsOf(lane.equipmentCode).plcReady }" /></div>
          <div class="signal"><span>Trigger_Write</span><i class="dot" :class="{ run: signalsOf(lane.equipmentCode).triggerWriteEcho }" /></div>
          <div class="signal"><span>Step_Running</span><i class="dot" :class="{ run: signalsOf(lane.equipmentCode).stepRunning }" /></div>
          <div class="signal"><span>Step_Complete</span><i class="dot" :class="{ on: signalsOf(lane.equipmentCode).stepComplete }" /></div>
          <div class="signal"><span>Step_Error</span><i class="dot" :class="{ err: signalsOf(lane.equipmentCode).stepError }" /></div>
          <div class="signal"><span>Host_Hold</span><i class="dot" :class="{ run: signalsOf(lane.equipmentCode).hostHoldEcho }" /></div>
          <div class="signal"><span>PLC_Held</span><i class="dot" :class="{ on: signalsOf(lane.equipmentCode).plcHeld }" /></div>
          <div class="signal"><span>Error_Code</span><span>{{ signalsOf(lane.equipmentCode).errorCode }}</span></div>
          <div class="signal"><span>Heartbeat</span><span>{{ signalsOf(lane.equipmentCode).heartbeat }}</span></div>
        </el-card>
        <el-alert v-if="awaitingConfirm && batch.status === 'Running'" type="info" title="等待人工确认" description="本工步禁止写 PLC。操作员 / 质量电子签名确认后才进入下一步。" style="margin-bottom:10px" />
        <el-alert v-if="batch.status === 'Held'" type="warning" :title="batch.faultMessage || '批次保持'" :description="heldHint" />
        <el-alert v-else-if="batch.faultMessage" type="error" :title="batch.faultMessage" :description="faultHint" />
        <el-card v-if="alarms.length" header="过程报警" style="margin-top:10px">
          <el-table :data="alarms" size="small">
            <el-table-column prop="stepCode" label="工步" width="70" fixed />
            <el-table-column prop="code" label="代码" width="120" />
            <el-table-column prop="message" label="说明" />
            <el-table-column label="确认" width="100">
              <template #default="{ row }">
                <el-button v-if="!row.acknowledgedAt && canAckAlarm" link type="primary" :loading="acking" @click="ackAlarm(row)">确认</el-button>
                <span v-else>{{ row.acknowledgedBy || "—" }}</span>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <el-col :span="8" :xs="24">
        <el-card>
          <template #header>
            <div class="trend-head">
              <span>实时工艺趋势</span>
              <el-radio-group v-model="chartKind" size="small">
                <el-radio-button value="echarts">ECharts</el-radio-button>
                <el-radio-button value="uplot">uPlot</el-radio-button>
              </el-radio-group>
            </div>
          </template>
          <div v-show="chartKind === 'echarts'" ref="chartEl" style="height:260px" />
          <div v-show="chartKind === 'uplot'" ref="uplotEl" style="height:260px" />
        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="12" style="margin-top:12px">
      <el-col :span="14" :xs="24">
        <el-card header="握手时序（禁止盲写）">
          <el-table :data="handshakeLog" size="small" max-height="240">
            <el-table-column prop="stepCode" label="工步" width="70" fixed />
            <el-table-column prop="phase" label="阶段" width="150" />
            <el-table-column prop="kind" label="动作" width="90" />
            <el-table-column prop="detail" label="说明" />
            <el-table-column prop="remainingSeconds" label="剩余s" width="70">
              <template #default="{ row }">{{ row.remainingSeconds == null ? "—" : Number(row.remainingSeconds).toFixed(0) }}</template>
            </el-table-column>
          </el-table>
          <div v-if="!handshakeLog.length" class="muted">启动批次后，此处按 PLC_Ready → Trigger_Write → Step_Running → Step_Complete 记录每一次合法动作。</div>
        </el-card>
      </el-col>
      <el-col :span="10" :xs="24">
        <el-card header="快照 vs 当前生效主配方">
          <el-alert
            v-if="hasDrift"
            :closable="false"
            type="warning"
            show-icon
            title="控制配方快照已冻结。主配方升版只体现在漂移列，禁止改写本批次写参。"
            style="margin-bottom:8px"
          />
          <el-table :data="drifts" size="small" max-height="240" :row-class-name="driftRowClass">
            <el-table-column prop="stepCode" label="工步" width="70" fixed />
            <el-table-column prop="parameter" label="参数" />
            <el-table-column prop="frozenSetpoint" label="快照" width="80" />
            <el-table-column prop="masterSetpoint" label="主配方" width="80" />
            <el-table-column label="漂移" width="70">
              <template #default="{ row }">{{ row.drifted ? "是" : "否" }}</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, reactive, ref, watch } from "vue";
import { useRoute } from "vue-router";
import { HubConnectionBuilder } from "@microsoft/signalr";
import * as echarts from "echarts";
import uPlot from "uplot";
import "uplot/dist/uPlot.min.css";
import { ElMessage, ElMessageBox } from "element-plus";
import http from "../../api/http";
import type { BatchDetailDto, EquipmentDto, ExecutionEvent, HandshakeLogDto, LaneHandshakeDto, ProcessAlarmDto, SampleDto, SnapshotDriftDto } from "../../api/types";
import { useAuthStore } from "../../stores/auth";
import ProcedureFlow from "../../components/ProcedureFlow.vue";
import SetpointMatrix from "../../components/SetpointMatrix.vue";
import PlcWritePlan from "../../components/PlcWritePlan.vue";
import { snapshotToMatrixSteps, measuredFromExecutions } from "../../setpointMatrix";
import { batchStatusLabel, handshakePhaseLabel, stepOutcomeLabel } from "../../utils/labels";
import { useLoad } from "../../utils/useLoad";
import { palette } from "../../utils/theme";
import HelpTip from "../../components/HelpTip.vue";

const route = useRoute();
const auth = useAuthStore();
const batch = ref<BatchDetailDto | null>(null);
const phase = ref("");
const chartEl = ref<HTMLDivElement | null>(null);
const uplotEl = ref<HTMLDivElement | null>(null);
const chartKind = ref<"echarts" | "uplot">("uplot");
type PlcSignals = { plcReady: boolean; stepRunning: boolean; stepComplete: boolean; stepError: boolean; errorCode: number; heartbeat: number; triggerWriteEcho: boolean; plcHeld: boolean; hostHoldEcho: boolean };
const emptySignals = (): PlcSignals => ({ plcReady: false, stepRunning: false, stepComplete: false, stepError: false, errorCode: 0, heartbeat: 0, triggerWriteEcho: false, plcHeld: false, hostHoldEcho: false });
const signals = reactive(emptySignals());
const laneSignals = reactive<Record<string, PlcSignals>>({});
const lanes = ref<LaneHandshakeDto[]>([]);
const selectedLaneCode = ref("");
const remainingByLane = reactive<Record<string, number | null>>({});
const series: Record<string, [number, number][]> = { Temperature: [], Pressure: [] };
const pickedStep = ref<string | null>(null);
const remainingSeconds = ref<number | null>(null);
const handshakeLog = ref<HandshakeLogDto[]>([]);
const alarms = ref<ProcessAlarmDto[]>([]);
const drifts = ref<SnapshotDriftDto[]>([]);
const livePlc = ref("");
const equipmentIndex = ref<Record<string, string>>({});
const { loading, error } = useLoad();
// 操作按钮防重入：任一签名+请求在途时，对应按钮显示 loading 且禁用，避免重复提交。
const busyAction = ref<string>("");
const acking = ref(false);
let chart: echarts.ECharts | null = null;
let plot: uPlot | null = null;
let conn: ReturnType<HubConnectionBuilder["build"]> | null = null;

function outcome(stepId: string) {
  return batch.value?.stepExecutions.find((s) => s.stepId === stepId)?.outcome ?? "Pending";
}

function timelineType(stepId: string) {
  const o = outcome(stepId);
  if (o === "Running") return "primary";
  if (o === "AwaitingConfirm") return "warning";
  if (o === "Held") return "warning";
  if (o === "Completed") return "success";
  if (o === "Skipped") return "warning";
  if (o === "Faulted") return "danger";
  return "info";
}

const displayLanes = computed(() => {
  if (lanes.value.length) return lanes.value;
  if (!batch.value) return [];
  return [{
    equipmentCode: livePlc.value || batch.value.equipmentName,
    equipmentId: batch.value.equipmentId,
    unitProcedure: "",
    stepId: batch.value.currentStepId,
    stepCode: batch.value.snapshot.steps[batch.value.currentStepIndex]?.code ?? "",
    phase: phase.value || batch.value.handshakePhase,
    outcome: "Running"
  } satisfies LaneHandshakeDto];
});

const selectedLane = computed(() =>
  displayLanes.value.find((l) => l.equipmentCode === selectedLaneCode.value) ?? displayLanes.value[0]);

const skipReady = computed(() => {
  const p = selectedLane.value?.phase || phase.value || batch.value?.handshakePhase || "";
  return p === "WaitingPlcReady" || p === "Held" || p === "AwaitingConfirm" || p === "HostWait";
});

const awaitingConfirm = computed(() => {
  const currentId = selectedLane.value?.stepId || batch.value?.currentStepId;
  const exec = batch.value?.stepExecutions.find((s) => s.stepId === currentId);
  if (exec?.outcome === "AwaitingConfirm") return true;
  const snap = batch.value?.snapshot.steps.find((s) => s.stepId === currentId);
  return snap?.type === "ManualConfirm" && exec?.outcome === "Running";
});

const heldHint = computed(() => {
  const msg = batch.value?.faultMessage ?? "";
  if (msg.includes("质检超差"))
    return "归档实测超出规格，已保持批次且禁止写下一步。质量/主管审核后恢复执行。";
  const p = selectedLane.value?.phase || phase.value || batch.value?.handshakePhase || "";
  if (p === "AwaitingConfirm" || awaitingConfirm.value)
    return "人工确认等待中被保持，未写 PLC。恢复后继续等待电子签名确认。";
  return "已写 Host_Hold 并收到 PLC_Held。恢复执行将清位并继续剩余工步时长，禁止盲写下一步。";
});

const handshakeSummary = computed(() => {
  // 多通道时按设备列出各自阶段。此前直接拼原始字符串（WaitingPlcReady），操作员看不懂。
  if (displayLanes.value.length > 1)
    return displayLanes.value.map((l) => `${l.equipmentCode}:${handshakePhaseLabel(l.phase)}`).join(" · ");
  return handshakePhaseLabel(selectedLane.value?.phase || phase.value || batch.value?.handshakePhase || "");
});

function signalsOf(code: string): PlcSignals {
  return laneSignals[code] ?? (selectedLaneCode.value === code || !code ? signals : emptySignals());
}

function selectLane(code: string) {
  selectedLaneCode.value = code;
  const inbound = laneSignals[code];
  if (inbound) Object.assign(signals, inbound);
  const lane = lanes.value.find((l) => l.equipmentCode === code);
  if (lane?.phase) phase.value = lane.phase;
  remainingSeconds.value = remainingByLane[code] ?? remainingSeconds.value;
}

const flowSteps = computed(() =>
  (batch.value?.snapshot.steps ?? []).map((s) => ({
    id: s.stepId,
    code: s.code,
    name: s.name,
    type: s.type,
    unitProcedure: s.unitProcedure,
    operation: s.operation,
    ordinal: s.ordinal
  }))
);
const flowEdges = computed(() => batch.value?.snapshot.edges ?? []);
const flowOutcomes = computed(() =>
  Object.fromEntries((batch.value?.stepExecutions ?? []).map((e) => [e.stepId, e.outcome]))
);
const matrixSteps = computed(() => snapshotToMatrixSteps(batch.value?.snapshot.steps ?? []));
const measured = computed(() =>
  measuredFromExecutions(matrixSteps.value, batch.value?.stepExecutions ?? [])
);

const unitGroups = computed(() => {
  const map = new Map<string, NonNullable<typeof batch.value>["snapshot"]["steps"]>();
  for (const s of batch.value?.snapshot.steps ?? []) {
    const name = s.unitProcedure?.trim() || "UP-01 热处理单元";
    const list = map.get(name);
    if (list) list.push(s);
    else map.set(name, [s]);
  }
  return [...map.entries()].map(([name, steps]) => ({ name, steps }));
});

const qualityRows = computed(() => {
  const execs = batch.value?.stepExecutions ?? [];
  const focused = pickedStep.value ? execs.filter((s) => s.stepId === pickedStep.value) : execs;
  const rows: { step: string; tag: string; value: string; spec: string; oos: boolean }[] = [];
  for (const exec of focused) {
    if (!exec.qualityJson || exec.outcome === "Skipped" || exec.outcome === "Faulted") continue;
    if (!exec.qualityJson.trim().startsWith("{")) continue;
    const snap = batch.value?.snapshot.steps.find((s) => s.stepId === exec.stepId);
    try {
      const parsed = JSON.parse(exec.qualityJson) as Record<string, unknown>;
      for (const [tag, value] of Object.entries(parsed)) {
        const numeric = typeof value === "number" ? value : Number(value);
        const param = snap?.parameters.find((p) => p.name === tag);
        const oos = param && Number.isFinite(numeric)
          ? (param.min != null && numeric < param.min) || (param.max != null && numeric > param.max)
          : false;
        const spec = param && (param.min != null || param.max != null)
          ? `${param.min ?? "—"}~${param.max ?? "—"}`
          : tag.startsWith("PLC:") ? "参考" : "—";
        rows.push({
          step: exec.stepCode,
          tag,
          value: Number.isFinite(numeric) ? numeric.toFixed(2) : String(value),
          spec: oos ? "超差" : spec,
          oos
        });
      }
    } catch {
      rows.push({ step: exec.stepCode, tag: "raw", value: exec.qualityJson, spec: "—", oos: false });
    }
  }
  return rows;
});

const canOperate = computed(() => auth.can("Operator", "Supervisor"));
const canSkip = computed(() => auth.can("Supervisor"));
const canConfirm = computed(() => auth.can("Operator", "Supervisor", "Quality"));
const canResume = computed(() => auth.can("Operator", "Supervisor", "Quality"));
const canAckAlarm = computed(() => auth.can("Operator", "Supervisor", "Quality"));
const hasDrift = computed(() => drifts.value.some((d) => d.drifted));
function driftRowClass({ row }: { row: SnapshotDriftDto }) {
  return row.drifted ? "drift-row" : "";
}
const integrityLabel = computed(() => ({
  Valid: "完整性有效",
  Legacy: "历史快照(无哈希)",
  Mismatch: "完整性失败",
  Corrupt: "快照损坏"
} as Record<string, string>)[batch.value?.snapshotIntegrity ?? ""] ?? (batch.value?.snapshotIntegrity ?? ""));
const scaleLabel = computed(() => {
  const snap = batch.value?.snapshot;
  if (!snap) return "";
  const parts: string[] = [];
  if (snap.scaleFactor != null && snap.scaleFactor !== 1) parts.push(`缩放 ×${snap.scaleFactor}`);
  if (snap.lotNumber) parts.push(`物料 ${snap.lotNumber}`);
  const bindings = snap.unitEquipment
    ? Object.entries(snap.unitEquipment).map(([unit, id]) => `${unit}→${equipmentIndex.value[id] ?? id.slice(0, 8)}`)
    : [];
  if (bindings.length) parts.push(bindings.join("，"));
  return parts.length ? ` · ${parts.join(" · ")}` : "";
});

const livePlcLabel = computed(() => livePlc.value ? ` · ${livePlc.value}` : "");

function unitEquipmentLabel(unit: string) {
  const id = batch.value?.snapshot.unitEquipment?.[unit];
  if (!id) return "";
  const code = equipmentIndex.value[id];
  return code ? ` · ${code}` : "";
}

const faultHint = computed(() => {
  const code = batch.value?.faultCode ?? "";
  const map: Record<string, string> = {
    PlcReadyTimeout: "等待 PLC_Ready 超时：检查握手位与通讯，确认 PLC 空闲后再重新排队。",
    HeartbeatLost: "工步执行中心跳丢失：检查看门狗时间与现场心跳程序。",
    ExecutionTimeout: "工步看门狗超时：核对设定值与 PLC 程序，必要时延长该工步看门狗。",
    AckTimeout: "Trigger_Write 后未收到 Step_Running：禁止盲写下一步，先复位握手位。",
    PlcReportedError: "PLC 报 Step_Error：读取 Error_Code 后按设备手册处理。",
    BlindWriteRejected: "状态机拒绝跨阶段写参，保持四步握手顺序。",
    WriteVerifyMismatch: "写参回读与快照不一致：禁止 Trigger_Write，检查点表与 PLC 程序后再重新排队。",
    HoldAckTimeout: "Host_Hold 后未收到 PLC_Held：禁止盲写下一步，检查保持握手位。"
  };
  return map[code] ?? "可在故障清除后重新排队，调度将从当前工步索引恢复握手。";
});

function cardClass(which: "A" | "B" | "C" | "D") {
  const p = selectedLane.value?.phase || phase.value || batch.value?.handshakePhase || "";
  const map: Record<string, string> = {
    A: "WaitingPlcReady WritingParameters",
    B: "AwaitingPlcAck",
    C: "StepRunning HostWait",
    D: "Completing ReadyToAdvance"
  };
  if (p === "Faulted") return "fault";
  return map[which].split(" ").includes(p) ? "active" : "";
}

async function load() {
  try {
    batch.value = (await http.get<BatchDetailDto>(`/batches/${route.params.id}`)).data;
    phase.value = batch.value.handshakePhase;
    lanes.value = batch.value.lanes ?? [];
    if (!selectedLaneCode.value && lanes.value[0]) selectedLaneCode.value = lanes.value[0].equipmentCode;
    if (selectedLane.value?.phase) phase.value = selectedLane.value.phase;
    const samples = (await http.get<SampleDto[]>(`/batches/${route.params.id}/samples`)).data;
    handshakeLog.value = (await http.get<HandshakeLogDto[]>(`/batches/${route.params.id}/handshake-log`)).data;
    alarms.value = (await http.get<ProcessAlarmDto[]>(`/batches/${route.params.id}/alarms`)).data;
    drifts.value = (await http.get<SnapshotDriftDto[]>(`/batches/${route.params.id}/snapshot-drift`)).data;
    equipmentIndex.value = Object.fromEntries(
      (await http.get<EquipmentDto[]>("/equipment")).data.map((e) => [e.id, e.code]));
    series.Temperature = [];
    series.Pressure = [];
    for (const s of samples) {
      if (!series[s.tag]) series[s.tag] = [];
      series[s.tag].push([new Date(s.sampledAt).getTime(), s.value]);
    }
    renderChart();
    error.value = "";
  } catch (e) {
    // 原先取数失败会留下空白页且无任何提示（根节点 v-if="batch"），这里显式报错。
    error.value = (e as Error).message || "批次详情加载失败";
  } finally {
    loading.value = false;
  }
}

function renderChart() {
  if (chartKind.value === "uplot") {
    renderUplot();
    return;
  }
  if (!chartEl.value) return;
  chart ??= echarts.init(chartEl.value);
  chart.setOption({
    backgroundColor: "transparent",
    tooltip: { trigger: "axis" },
    legend: { data: Object.keys(series), textStyle: { color: palette("--text-body") } },
    xAxis: { type: "time", axisLabel: { color: palette("--muted") } },
    yAxis: { type: "value", axisLabel: { color: palette("--muted") }, splitLine: { lineStyle: { color: palette("--line") } } },
    series: Object.entries(series).map(([name, data]) => ({ name, type: "line", showSymbol: false, data }))
  });
}

function renderUplot() {
  if (!uplotEl.value) return;
  const names = Object.keys(series);
  const xs: number[] = [];
  const seen = new Set<number>();
  for (const pts of Object.values(series)) {
    for (const [t] of pts) {
      if (!seen.has(t)) {
        seen.add(t);
        xs.push(t);
      }
    }
  }
  xs.sort((a, b) => a - b);
  const data: uPlot.AlignedData = [new Float64Array(xs)];
  for (const name of names) {
    const map = new Map(series[name]);
    data.push(xs.map((t) => map.get(t) ?? null) as unknown as Float64Array);
  }
  plot?.destroy();
  plot = new uPlot({
    width: Math.max(uplotEl.value.clientWidth || 360, 240),
    height: 260,
    legend: { show: true },
    axes: [
      { stroke: palette("--muted"), grid: { stroke: palette("--line") } },
      { stroke: palette("--muted"), grid: { stroke: palette("--line") } }
    ],
    series: [
      {},
      ...names.map((name, i) => ({
        label: name,
        stroke: i === 0 ? palette("--warn") : palette("--cool"),
        width: 1.4
      }))
    ]
  }, data, uplotEl.value);
}

async function esign(title: string, needReason = false) {
  let reason: string | undefined;
  if (needReason) {
    const box = await ElMessageBox.prompt("原因 / 意见", title);
    reason = box.value;
  }
  const { value: password } = await ElMessageBox.prompt("请再次输入登录密码作为电子签名", title, {
    inputType: "password"
  });
  return { password, reason };
}

async function start() {
  busyAction.value = "start";
  try {
    const { password } = await esign(batch.value?.status === "Faulted" ? "故障后重新排队" : "启动批次");
    await http.post(`/batches/${batch.value!.id}/start`, { password });
    await load();
  } catch (e) {
    if ((e as string) !== "cancel") ElMessage.error((e as Error).message ?? String(e));
  } finally {
    busyAction.value = "";
  }
}

async function abort() {
  busyAction.value = "abort";
  try {
    const { password, reason } = await esign("中止批次", true);
    await http.post(`/batches/${batch.value!.id}/abort`, { password, reason: reason ?? "操作员中止" });
    await load();
  } catch (e) {
    if ((e as string) !== "cancel") ElMessage.error((e as Error).message ?? String(e));
  } finally {
    busyAction.value = "";
  }
}

async function hold() {
  busyAction.value = "hold";
  try {
    const { password, reason } = await esign("保持批次（写 Host_Hold，等待 PLC_Held，禁止盲写）", true);
    await http.post(`/batches/${batch.value!.id}/hold`, { password, reason: reason ?? "操作员保持" });
    ElMessage.success("已请求保持：上位机写 Host_Hold，等待 PLC_Held 后暂停剩余时长。");
    await load();
  } catch (e) {
    if ((e as string) !== "cancel") ElMessage.error((e as Error).message ?? String(e));
  } finally {
    busyAction.value = "";
  }
}

async function resume() {
  busyAction.value = "resume";
  try {
    const { password } = await esign("恢复执行");
    await http.post(`/batches/${batch.value!.id}/resume`, { password });
    await load();
  } catch (e) {
    if ((e as string) !== "cancel") ElMessage.error((e as Error).message ?? String(e));
  } finally {
    busyAction.value = "";
  }
}

function skipTargetStepId(): string | undefined {
  const execs = batch.value?.stepExecutions ?? [];
  const live = (id?: string | null) => {
    if (!id) return undefined;
    const exec = execs.find((s) => s.stepId === id);
    return exec && ["Running", "AwaitingConfirm", "Held", "Faulted"].includes(exec.outcome) ? id : undefined;
  };
  return live(selectedLane.value?.stepId)
    ?? live(batch.value?.currentStepId)
    ?? execs.find((s) => ["Running", "AwaitingConfirm", "Held", "Faulted"].includes(s.outcome))?.stepId;
}

async function skip() {
  busyAction.value = "skip";
  try {
    const { password, reason } = await esign("跳过当前工步（仅 PLC_Ready / 等待 / 人工确认，且未写参）", true);
    await http.post(`/batches/${batch.value!.id}/skip`, {
      password,
      reason: reason ?? "主管跳步",
      stepId: skipTargetStepId()
    });
    await load();
  } catch (e) {
    if ((e as string) !== "cancel") ElMessage.error((e as Error).message ?? String(e));
  } finally {
    busyAction.value = "";
  }
}

async function ackAlarm(row: ProcessAlarmDto) {
  acking.value = true;
  try {
    await http.post(`/alarms/${row.id}/ack`);
    await load();
  } catch (e) {
    ElMessage.error((e as Error).message);
  } finally {
    acking.value = false;
  }
}

async function confirmStep() {
  busyAction.value = "confirm";
  try {
    const currentId = selectedLane.value?.stepId || batch.value?.currentStepId;
    const { password, reason } = await esign("人工确认本工步（禁止写 PLC）", true);
    await http.post(`/batches/${batch.value!.id}/confirm`, {
      password,
      reason: reason ?? "操作员确认",
      stepId: currentId
    });
    ElMessage.success("已提交人工确认，调度将完成该工步且不写 PLC。");
    await load();
  } catch (e) {
    if ((e as string) !== "cancel") ElMessage.error((e as Error).message ?? String(e));
  } finally {
    busyAction.value = "";
  }
}

watch(chartKind, async () => {
  await nextTick();
  renderChart();
});

onMounted(async () => {
  await load();
  await nextTick();
  renderChart();
  conn = new HubConnectionBuilder()
    .withUrl(`/hubs/execution?access_token=${auth.token}`)
    .withAutomaticReconnect()
    .build();
  conn.on("execution", (evt: ExecutionEvent) => {
    if (evt.batchId !== batch.value?.id) return;
    if (evt.type === "handshake") {
      const payload = evt.payload as {
        phase: string;
        inbound: typeof signals;
        status: string;
        stepId: string;
        stepIndex: number;
        remainingSeconds?: number | null;
        equipmentCode?: string;
        unitProcedure?: string;
        stepCode?: string;
        stepName?: string;
      };
      if (payload.equipmentCode) {
        livePlc.value = payload.equipmentCode;
        if (!selectedLaneCode.value) selectedLaneCode.value = payload.equipmentCode;
        remainingByLane[payload.equipmentCode] = payload.remainingSeconds ?? null;
        if (payload.inbound)
          laneSignals[payload.equipmentCode] = { ...payload.inbound };
        const idx = lanes.value.findIndex((l) => l.equipmentCode === payload.equipmentCode);
        const next: LaneHandshakeDto = {
          equipmentCode: payload.equipmentCode,
          equipmentId: idx >= 0 ? lanes.value[idx].equipmentId : "",
          unitProcedure: payload.unitProcedure ?? (idx >= 0 ? lanes.value[idx].unitProcedure : ""),
          stepId: payload.stepId,
          stepCode: payload.stepCode ?? (idx >= 0 ? lanes.value[idx].stepCode : ""),
          phase: payload.phase,
          outcome: "Running"
        };
        if (idx >= 0) lanes.value[idx] = { ...lanes.value[idx], ...next };
        else lanes.value = [...lanes.value, next];
        if (payload.equipmentCode === selectedLaneCode.value || displayLanes.value.length <= 1) {
          phase.value = payload.phase;
          remainingSeconds.value = payload.remainingSeconds ?? null;
          Object.assign(signals, payload.inbound);
        }
      } else {
        phase.value = payload.phase;
        remainingSeconds.value = payload.remainingSeconds ?? null;
        Object.assign(signals, payload.inbound);
      }
      if (batch.value) {
        batch.value.status = payload.status as BatchDetailDto["status"];
        batch.value.currentStepIndex = payload.stepIndex;
        batch.value.currentStepId = payload.stepId;
        const exec = batch.value.stepExecutions.find((s) => s.stepId === payload.stepId);
        if (exec) {
          if (payload.status === "Held") exec.outcome = "Held";
          else if (payload.phase === "AwaitingConfirm") exec.outcome = "AwaitingConfirm";
          else if (exec.outcome === "Pending") exec.outcome = "Running";
        }
      }
    }
    if (evt.type === "step") {
      const payload = evt.payload as { stepId: string; stepIndex: number; outcome: string; qualityJson?: string };
      if (batch.value) {
        batch.value.currentStepIndex = payload.stepIndex;
        batch.value.currentStepId = payload.stepId;
        pickedStep.value = payload.stepId;
        const exec = batch.value.stepExecutions.find((s) => s.stepId === payload.stepId);
        if (exec) {
          exec.outcome = payload.outcome;
          if (payload.qualityJson) exec.qualityJson = payload.qualityJson;
        }
        const lane = lanes.value.find((l) => l.stepId === payload.stepId);
        if (lane) lane.outcome = payload.outcome;
      }
    }
    if (evt.type === "sample") {
      const measured = evt.payload as Record<string, number>;
      const t = Date.now();
      for (const [tag, value] of Object.entries(measured)) {
        series[tag] ??= [];
        series[tag].push([t, value]);
      }
      renderChart();
    }
    if (evt.type === "completed" || evt.type === "fault" || evt.type === "aborted" || evt.type === "held" || evt.type === "alarm") load();
  });
  await conn.start();
  await conn.invoke("SubscribeBatch", batch.value!.id);
});

onUnmounted(() => {
  conn?.stop();
  plot?.destroy();
  chart?.dispose();
});
</script>

<style scoped>
.step-line { cursor: pointer; }
.muted { color: var(--muted); font-size: 12px; }
.trend-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.up-group { margin-bottom: 12px; }
.up-title { font-size: 12px; color: var(--accent-bright); margin: 0 0 6px; letter-spacing: 0.3px; }
.lane-card { cursor: pointer; }
.lane-card.selected { outline: 1px solid var(--accent); }
:deep(.drift-row) { color: var(--warn); }
</style>
