<template>
  <div>
    <div class="page-title"><h2>运行总览</h2></div>
    <el-row :gutter="12">
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi clickable" @click="openBatches('Running')"><div class="kpi-label">执行中批次</div><h1 class="kpi-value">{{ dash?.runningBatches ?? 0 }}</h1></el-card></el-col>
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi clickable" @click="openBatches('Queued')"><div class="kpi-label">排队批次</div><h1 class="kpi-value">{{ dash?.queuedBatches ?? 0 }}</h1></el-card></el-col>
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi" :class="{ clickable: canApprovals }" @click="openApprovals"><div class="kpi-label">待审核配方</div><h1 class="kpi-value">{{ dash?.pendingApprovals ?? 0 }}</h1></el-card></el-col>
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi"><div class="kpi-label">已批准配方</div><h1 class="kpi-value">{{ dash?.approvedRecipes ?? 0 }}</h1></el-card></el-col>
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi clickable" @click="openBatches('Faulted')"><div class="kpi-label">握手故障批次</div><h1 class="kpi-value">{{ dash?.faultedBatches ?? 0 }}</h1></el-card></el-col>
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi" :class="{ clickable: canAlarms }" @click="openAlarms"><div class="kpi-label">未确认报警</div><h1 class="kpi-value">{{ dash?.openAlarms ?? 0 }}</h1></el-card></el-col>
    </el-row>
    <el-row :gutter="12" style="margin-top:12px">
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi clickable" @click="openBatches('Completed')"><div class="kpi-label">待质量放行</div><h1 class="kpi-value">{{ dash?.pendingReleaseBatches ?? 0 }}</h1></el-card></el-col>
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi clickable" @click="$router.push('/lots')"><div class="kpi-label">待检终样</div><h1 class="kpi-value">{{ dash?.pendingLabSamples ?? 0 }}</h1></el-card></el-col>
      <el-col :span="4" :xs="12" :sm="8" :md="6"><el-card class="kpi"><div class="kpi-label">草稿版本</div><h1 class="kpi-value">{{ dash?.draftRecipes ?? 0 }}</h1></el-card></el-col>
      <el-col :span="12" :xs="24" :sm="24">
        <el-card header="执行态势（ECharts）">
          <div ref="chartEl" style="height:140px" />
        </el-card>
      </el-col>
    </el-row>
    <el-alert
      v-if="loadError"
      :closable="false"
      type="error"
      :title="`数据加载失败：${loadError}`"
      description="页面会每 4 秒自动重试；若持续失败请检查后端 API 是否已启动。"
      show-icon
      style="margin-top:12px"
    />
    <el-alert
      :closable="false"
      :type="health?.status === 'ok' ? 'success' : 'error'"
      :title="health?.status === 'ok' ? `服务健康 · ${health.database ?? 'sqlite'} · 控制配方 ${health.controlRecipe ?? 'text'}` : 'API 健康检查失败'"
      style="margin-top:12px"
    />
      <el-card style="margin-top:16px" header="设备占用（一台设备同时只允许一个运行/排队/保持批次）">
        <el-table
          :data="dash?.equipmentOccupancy ?? []"
          v-loading="initialLoading"
          empty-text="暂无设备数据"
          class="clickable-rows"
          @row-click="openOccupant"
        >
          <el-table-column prop="code" label="设备" width="90" fixed />
          <el-table-column prop="name" label="名称" />
          <el-table-column prop="protocol" label="协议" width="120">
            <template #default="{ row }">{{ protocolLabel(row.protocol) }}</template>
          </el-table-column>
          <el-table-column prop="occupancy" width="90">
            <template #header><HelpTip term="设备占用" /></template>
            <template #default="{ row }">
              <el-tag size="small" :type="occupancyTagType(row.occupancy)" effect="dark">{{ occupancyLabel(row.occupancy) }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="batchNo" label="批次" width="160" />
          <el-table-column prop="batchStatus" label="批次状态" width="120">
            <template #default="{ row }">
              <el-tag size="small" :type="batchStatusTagType(row.batchStatus)" effect="dark">{{ batchStatusLabel(row.batchStatus) }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="handshakePhase">
            <template #header><HelpTip term="四步握手" /></template>
            <template #default="{ row }">
              <HelpTip :term="handshakePhaseLabel(row.handshakePhase)">{{ handshakePhaseLabel(row.handshakePhase) }}</HelpTip>
            </template>
          </el-table-column>
        </el-table>
      </el-card>
      <el-card style="margin-top:16px" header="实时批次">
        <el-table
          :data="dash?.liveBatches ?? []"
          v-loading="initialLoading"
          empty-text="当前没有执行中的批次"
          class="clickable-rows"
          @row-click="(row: BatchListItemDto) => $router.push(`/batches/${row.id}`)"
        >
          <el-table-column prop="batchNo" label="批次号" min-width="150" fixed />
          <el-table-column prop="recipeName" label="配方" />
          <el-table-column prop="status" label="状态" width="120">
            <template #default="{ row }">
              <el-tag size="small" :type="batchStatusTagType(row.status)" effect="dark">{{ batchStatusLabel(row.status) }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="handshakePhase">
            <template #header><HelpTip term="四步握手" /></template>
            <template #default="{ row }">
              <HelpTip :term="handshakePhaseLabel(row.handshakePhase)">{{ handshakePhaseLabel(row.handshakePhase) }}</HelpTip>
            </template>
          </el-table-column>
          <el-table-column prop="equipmentCode" label="设备" width="110" />
        </el-table>
      </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref } from "vue";
import { useRouter } from "vue-router";
import * as echarts from "echarts";
import http from "../api/http";
import type { BatchListItemDto, DashboardDto, EquipmentOccupancyDto, ExecutionEvent, HealthDto } from "../api/types";
import { occupancyFromEvent, useExecutionHub } from "../realtime/executionHub";
import { useAuthStore } from "../stores/auth";
import HelpTip from "../components/HelpTip.vue";
import { palette } from "../utils/theme";
import {
  batchStatusLabel,
  batchStatusTagType,
  handshakePhaseLabel,
  occupancyLabel,
  occupancyTagType,
  protocolLabel
} from "../utils/labels";

const auth = useAuthStore();
const dash = ref<DashboardDto | null>(null);
const health = ref<HealthDto | null>(null);
// 仅首屏展示加载态；轮询刷新不再闪 loading，避免 4s 一次的视觉抖动。
const initialLoading = ref(true);
const loadError = ref("");
const chartEl = ref<HTMLDivElement | null>(null);
const router = useRouter();
const canApprovals = computed(() => auth.can("Supervisor", "Quality"));
const canAlarms = computed(() => auth.can("Admin", "Operator", "Supervisor", "Quality"));
let timer: number | undefined;
let chart: echarts.ECharts | null = null;

function openOccupant(row: EquipmentOccupancyDto) {
  if (row.batchId) router.push(`/batches/${row.batchId}`);
}

function openBatches(status: string) {
  void router.push({ path: "/batches", query: { status } });
}

function openApprovals() {
  if (canApprovals.value) void router.push("/approvals");
}

function openAlarms() {
  if (canAlarms.value) void router.push("/alarms");
}

async function load() {
  try {
    dash.value = (await http.get<DashboardDto>("/dashboard")).data;
    loadError.value = "";
  } catch (e) {
    // 原先首屏取数失败会静默留一堆 0，看起来像"真没数据"，这里显式报错。
    loadError.value = (e as Error).message || "运行总览数据加载失败";
  } finally {
    initialLoading.value = false;
  }
  try {
    health.value = (await http.get<HealthDto>("/health")).data;
  } catch {
    health.value = { status: "unhealthy" };
  }
  await nextTick();
  renderChart();
}

function renderChart() {
  if (!chartEl.value) return;
  chart ??= echarts.init(chartEl.value);
  const d = dash.value;
  chart.setOption({
    backgroundColor: "transparent",
    grid: { left: 8, right: 8, top: 24, bottom: 24, containLabel: true },
    tooltip: { trigger: "axis" },
    xAxis: {
      type: "category",
      data: ["执行中", "排队", "故障", "待放行", "未确认报警"],
      axisLabel: { color: palette("--muted"), fontSize: 11 }
    },
    yAxis: { type: "value", minInterval: 1, axisLabel: { color: palette("--muted") }, splitLine: { lineStyle: { color: palette("--line") } } },
    series: [
      {
        type: "bar",
        barWidth: 22,
        data: [
          d?.runningBatches ?? 0,
          d?.queuedBatches ?? 0,
          d?.faultedBatches ?? 0,
          d?.pendingReleaseBatches ?? 0,
          d?.openAlarms ?? 0
        ],
        itemStyle: { color: palette("--accent-bright") }
      }
    ]
  });
}

function onExecution(evt: ExecutionEvent) {
  const occupancy = occupancyFromEvent(evt);
  if (occupancy && dash.value)
    dash.value = { ...dash.value, equipmentOccupancy: occupancy };
  void load();
}

useExecutionHub({ onExecution });

onMounted(async () => {
  await load();
  timer = window.setInterval(load, 4000);
  window.addEventListener("resize", onResize);
});

function onResize() {
  chart?.resize();
}

onUnmounted(() => {
  if (timer) clearInterval(timer);
  window.removeEventListener("resize", onResize);
  chart?.dispose();
  chart = null;
});
</script>

<style scoped>
.clickable { cursor: pointer; }
/* KPI 卡：原先 <div>/<h1> 用浏览器默认样式，字号与间距偏松散且与页面节奏不一致 */
.kpi { transition: border-color 0.18s ease, background-color 0.18s ease, transform 0.18s ease; }
.kpi-label { color: var(--muted); font-size: 13px; }
.kpi-value { margin-top: 6px; font-size: 30px; font-weight: 600; letter-spacing: 0.5px; font-variant-numeric: tabular-nums; }
/* 可点击的 KPI 卡此前只有 cursor:pointer，缺悬停反馈 */
.clickable:hover { border-color: var(--accent); background-color: var(--raised); transform: translateY(-2px); }
</style>
