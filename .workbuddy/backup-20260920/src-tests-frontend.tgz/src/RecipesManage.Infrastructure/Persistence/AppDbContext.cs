using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using RecipesManage.Application.Contracts;
using RecipesManage.Domain.Batches;
using RecipesManage.Domain.Common;
using RecipesManage.Domain.Equipment;
using RecipesManage.Domain.Identity;
using RecipesManage.Domain.Materials;
using RecipesManage.Domain.Recipes;
using RecipesManage.Infrastructure.Plc;

namespace RecipesManage.Infrastructure.Persistence;

public sealed class AppDbContext : DbContext, IAppDbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<MasterRecipe> Recipes => Set<MasterRecipe>();
    public DbSet<RecipeVersion> RecipeVersions => Set<RecipeVersion>();
    public DbSet<RecipeStep> RecipeSteps => Set<RecipeStep>();
    public DbSet<RecipeEdge> RecipeEdges => Set<RecipeEdge>();
    public DbSet<RecipeParameter> RecipeParameters => Set<RecipeParameter>();
    public DbSet<ApprovalRecord> ApprovalRecords => Set<ApprovalRecord>();
    public DbSet<EquipmentLine> Equipment => Set<EquipmentLine>();
    public DbSet<EquipmentClass> EquipmentClasses => Set<EquipmentClass>();
    public DbSet<PhaseTemplate> PhaseTemplates => Set<PhaseTemplate>();
    public DbSet<ProductionBatch> Batches => Set<ProductionBatch>();
    public DbSet<BatchStepExecution> BatchStepExecutions => Set<BatchStepExecution>();
    public DbSet<ProcessSample> ProcessSamples => Set<ProcessSample>();
    public DbSet<LabSample> LabSamples => Set<LabSample>();
    public DbSet<MaterialLot> MaterialLots => Set<MaterialLot>();
    public DbSet<BatchMaterialUse> BatchMaterialUses => Set<BatchMaterialUse>();
    public DbSet<HandshakeEvent> HandshakeEvents => Set<HandshakeEvent>();
    public DbSet<ProcessAlarm> ProcessAlarms => Set<ProcessAlarm>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var jsonType = RecipesDatabase.HealthName(Database) == RecipesDatabase.PostgreSql
            ? "jsonb"
            : "TEXT";

        modelBuilder.Entity<AppUser>(e =>
        {
            e.ToTable("users");
            e.HasIndex(x => x.UserName).IsUnique();
            e.Property(x => x.UserName).HasMaxLength(64);
            e.Property(x => x.DisplayName).HasMaxLength(64);
        });

        modelBuilder.Entity<AuditLog>(e =>
        {
            e.ToTable("audit_logs");
            e.HasIndex(x => x.At);
        });

        modelBuilder.Entity<MasterRecipe>(e =>
        {
            e.ToTable("master_recipes");
            e.HasIndex(x => x.Code).IsUnique();
            e.HasMany(x => x.Versions).WithOne().HasForeignKey(x => x.MasterRecipeId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<RecipeVersion>(e =>
        {
            e.ToTable("recipe_versions");
            e.HasIndex(x => new { x.MasterRecipeId, x.VersionNumber }).IsUnique();
            e.HasMany(x => x.Steps).WithOne().HasForeignKey(x => x.RecipeVersionId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Edges).WithOne().HasForeignKey(x => x.RecipeVersionId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Approvals).WithOne().HasForeignKey(x => x.RecipeVersionId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<RecipeStep>(e =>
        {
            e.ToTable("recipe_steps");
            e.HasMany(x => x.Parameters).WithOne().HasForeignKey(x => x.RecipeStepId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<RecipeEdge>().ToTable("recipe_edges");
        modelBuilder.Entity<RecipeParameter>().ToTable("recipe_parameters");
        modelBuilder.Entity<ApprovalRecord>().ToTable("approval_records");

        modelBuilder.Entity<EquipmentLine>(e =>
        {
            e.ToTable("equipment");
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.TagMapJson).HasColumnType(jsonType);
            e.Property(x => x.WatchdogJson).HasColumnType(jsonType);
        });

        modelBuilder.Entity<EquipmentClass>(e =>
        {
            e.ToTable("equipment_classes");
            e.HasIndex(x => x.Code).IsUnique();
            e.HasMany(x => x.Templates).WithOne().HasForeignKey(x => x.EquipmentClassId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<PhaseTemplate>(e =>
        {
            e.ToTable("phase_templates");
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.ParametersJson).HasColumnType(jsonType);
        });

        modelBuilder.Entity<ProductionBatch>(e =>
        {
            e.ToTable("production_batches");
            e.HasIndex(x => x.BatchNo).IsUnique();
            e.Property(x => x.ControlRecipeJson).HasColumnType(jsonType);
            e.HasMany(x => x.StepExecutions).WithOne().HasForeignKey(x => x.BatchId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Samples).WithOne().HasForeignKey(x => x.BatchId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<BatchStepExecution>().ToTable("batch_step_executions");
        modelBuilder.Entity<ProcessSample>(e =>
        {
            e.ToTable("process_samples");
            e.HasIndex(x => new { x.BatchId, x.SampledAt });
        });

        modelBuilder.Entity<LabSample>(e =>
        {
            e.ToTable("lab_samples");
            e.HasIndex(x => x.SampleCode).IsUnique();
            e.HasIndex(x => x.BatchId);
            e.Property(x => x.ResultsJson).HasColumnType(jsonType);
        });

        modelBuilder.Entity<MaterialLot>(e =>
        {
            e.ToTable("material_lots");
            e.HasIndex(x => x.LotNumber).IsUnique();
            e.HasIndex(x => x.ParentLotId);
        });

        modelBuilder.Entity<BatchMaterialUse>(e =>
        {
            e.ToTable("batch_material_uses");
            e.HasIndex(x => new { x.BatchId, x.MaterialLotId, x.Role }).IsUnique();
        });

        modelBuilder.Entity<HandshakeEvent>(e =>
        {
            e.ToTable("handshake_events");
            e.HasIndex(x => x.BatchId);
        });

        modelBuilder.Entity<ProcessAlarm>(e =>
        {
            e.ToTable("process_alarms");
            e.HasIndex(x => x.BatchId);
            e.HasIndex(x => x.RaisedAt);
        });

        // Client-generated Guids must not be ValueGeneratedOnAdd: EF would treat clones as
        // existing rows and emit UPDATE ... WHERE Id = <new-guid> (0 rows → concurrency 500).
        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            var id = entityType.FindProperty(nameof(Entity.Id));
            if (id?.ClrType == typeof(Guid))
                id.ValueGenerated = Microsoft.EntityFrameworkCore.Metadata.ValueGenerated.Never;
        }
    }
}

public sealed class BcryptPasswordHasher : IPasswordHasher
{
    public string Hash(string password) => BCrypt.Net.BCrypt.HashPassword(password);
    public bool Verify(string password, string hash) => BCrypt.Net.BCrypt.Verify(password, hash);
}

public static class DatabaseSeeder
{
    public static async Task SeedAsync(AppDbContext db, IPasswordHasher hasher, CancellationToken ct = default)
    {
        if (!await db.Users.AnyAsync(ct))
        {
            db.Users.AddRange(
                new AppUser("admin", "系统管理员", hasher.Hash("Admin@123"), UserRole.Admin),
                new AppUser("engineer", "工艺工程师", hasher.Hash("Engineer@123"), UserRole.ProcessEngineer),
                new AppUser("supervisor", "工艺主管", hasher.Hash("Supervisor@123"), UserRole.Supervisor),
                new AppUser("qa", "质量工程师", hasher.Hash("Quality@123"), UserRole.Quality),
                new AppUser("operator", "车间操作员", hasher.Hash("Operator@123"), UserRole.Operator));
        }

        if (!await db.Equipment.AnyAsync(ct))
        {
            var tagMap = JsonSerializer.Serialize(new HandshakeTagMap());
            db.Equipment.Add(new EquipmentLine(
                "HT-01", "1# 热处理炉", PlcProtocol.Simulator, "127.0.0.1", 102,
                "S7_1200", 0, 1, tagMap, "开发用进程内 PLC 仿真器，完整四步握手。"));
        }

        await db.SaveChangesAsync(ct);

        if (!await db.Recipes.AnyAsync(ct))
        {
            var engineer = await db.Users.SingleAsync(u => u.UserName == "engineer", ct);
            var supervisor = await db.Users.SingleAsync(u => u.UserName == "supervisor", ct);
            var qa = await db.Users.SingleAsync(u => u.UserName == "qa", ct);

            var recipe = MasterRecipe.Create("AL-HT-T6", "Al-6061-T6 热处理", "AL6061", "铝合金 6061 锻件",
                "固溶 + 时效的示范主配方，用于联调握手闭环。", engineer.Id);

            var draft = recipe.RequireDraft();
            var s1 = Heat("S10", "升温至固溶温度", StepType.Heat, 0, 80, 120, 180,
                P(0, "目标温度", "℃", 530, 520, 540, true, true),
                P(1, "升温斜率", "℃/min", 8, 4, 12, true, false),
                P(2, "升温时长", "s", 8, 0.5, 3600, false, false));
            var s2 = Heat("S20", "固溶保温", StepType.Hold, 1, 360, 120, 240,
                P(0, "保温温度", "℃", 530, 525, 535, true, true),
                P(1, "保温时长", "s", 8, 1, 3600, true, true));
            var s3 = Heat("S30", "淬火冷却", StepType.Cool, 2, 640, 120, 90,
                P(0, "终点温度", "℃", 40, 20, 60, true, true),
                P(1, "冷却时长", "s", 6, 1, 600, true, false));
            var s4 = Heat("S40", "时效保温", StepType.Hold, 3, 920, 120, 200,
                P(0, "时效温度", "℃", 175, 170, 180, true, true),
                P(1, "时效时长", "s", 8, 1, 7200, true, true));
            var s5 = Heat("S50", "出炉质检采样", StepType.QualityCheck, 4, 1200, 120, 60,
                P(0, "硬度下限", "HB", 95, 90, 110, false, true));

            draft.ReplaceProcedure(
                [s1, s2, s3, s4, s5],
                [
                    new RecipeEdge(draft.Id, s1.Id, s2.Id),
                    new RecipeEdge(draft.Id, s2.Id, s3.Id),
                    new RecipeEdge(draft.Id, s3.Id, s4.Id),
                    new RecipeEdge(draft.Id, s4.Id, s5.Id)
                ]);

            draft.Submit(DateTimeOffset.UtcNow.AddMinutes(-10), engineer.Id, engineer.DisplayName, "提交示范配方审核");
            draft.Decide(ApprovalLevel.Supervisor, supervisor.Id, supervisor.DisplayName, ApprovalDecision.Approved, "工艺路径合理", DateTimeOffset.UtcNow.AddMinutes(-8));
            draft.Decide(ApprovalLevel.Quality, qa.Id, qa.DisplayName, ApprovalDecision.Approved, "参数窗口可接受", DateTimeOffset.UtcNow.AddMinutes(-5));
            recipe.MarkApproved(draft);

            db.Recipes.Add(recipe);
            await db.SaveChangesAsync(ct);

            RecipeStep Heat(string code, string name, StepType type, int ordinal, double x, double y, int watchdog, params RecipeParameter[] parameters) =>
                new(draft.Id, code, name, type, ordinal, x, y, watchdog, null, parameters, null,
                    Isa88.DefaultUnitProcedure, Isa88.DefaultOperation(type));

            static RecipeParameter P(int slot, string name, string unit, double sp, double min, double max, bool write, bool qc) =>
                new(slot, name, unit, sp, min, max, write, qc);
        }

        await EnsureModbusLoopbackAsync(db, ct);
        await EnsureOpcUaLoopbackAsync(db, ct);
        await EnsureSiemensLoopbackAsync(db, ct);
        await EnsureParallelDemoAsync(db, ct);
        await EnsureConfirmAndOosDemoAsync(db, ct);
        await EnsureWaitAndProcessOpsDemoAsync(db, ct);
        await RepairHoldTagsAsync(db, ct);
        await RepairMojibakeAsync(db, ct);
        await RepairIsa88Async(db, ct);
        await RepairHeatProcessDurationAsync(db, ct);
        await EnsureDemoLotsAsync(db, ct);
        await EnsurePhaseLibraryAsync(db, ct);
    }

    private static async Task EnsurePhaseLibraryAsync(AppDbContext db, CancellationToken ct)
    {
        if (!await db.EquipmentClasses.AnyAsync(ct))
        {
            static PhaseParameterSpec Spec(int slot, string name, string unit, double sp, double? min, double? max, bool write, bool qc, bool scale = false) =>
                new()
                {
                    SlotIndex = slot, Name = name, EngineeringUnit = unit, Setpoint = sp,
                    Min = min, Max = max, WriteToPlc = write, ArchiveAsQuality = qc, ScaleWithBatch = scale
                };

            var furnace = new EquipmentClass("FURNACE", "热处理炉", "允许 Heat / Hold / Cool 相写入 PLC。");
            furnace.AddTemplate("PH-HEAT", "升温至设定点", StepType.Heat, Isa88.DefaultOperation(StepType.Heat), 180,
            [
                Spec(0, "目标温度", "℃", 530, 520, 540, true, true),
                Spec(1, "升温斜率", "℃/min", 8, 4, 12, true, false),
                Spec(2, "升温时长", "s", 8, 0.5, 3600, false, false)
            ]);
            furnace.AddTemplate("PH-HOLD", "保温保持", StepType.Hold, Isa88.DefaultOperation(StepType.Hold), 240,
            [
                Spec(0, "保温温度", "℃", 530, 525, 535, true, true),
                Spec(1, "保温时长", "s", 8, 1, 3600, true, true)
            ]);
            furnace.AddTemplate("PH-COOL", "冷却至终点", StepType.Cool, Isa88.DefaultOperation(StepType.Cool), 120,
            [
                Spec(0, "终点温度", "℃", 40, 20, 60, true, true),
                Spec(1, "冷却时长", "s", 6, 1, 600, true, false)
            ]);

            var quench = new EquipmentClass("QUENCH", "淬火槽", "仅允许 Cool 相写入 PLC。");
            quench.AddTemplate("PH-QUENCH", "淬火冷却", StepType.Cool, Isa88.DefaultOperation(StepType.Cool), 90,
            [
                Spec(0, "终点温度", "℃", 40, 20, 60, true, true),
                Spec(1, "冷却时长", "s", 6, 1, 600, true, false)
            ]);

            var process = new EquipmentClass("PROCESS", "搅拌加压转移单元", "Mix / Pressure / Transfer。");
            process.AddTemplate("PH-MIX", "搅拌混合", StepType.Mix, Isa88.DefaultOperation(StepType.Mix), 60,
            [
                Spec(0, "搅拌转速", "rpm", 60, 10, 200, true, false),
                Spec(1, "搅拌时长", "s", 8, 1, 600, true, true)
            ]);
            process.AddTemplate("PH-PRESS", "加压保压", StepType.Pressure, Isa88.DefaultOperation(StepType.Pressure), 60,
            [
                Spec(0, "目标压力", "bar", 2.5, 1, 6, true, true),
                Spec(1, "保压时长", "s", 6, 1, 600, true, false)
            ]);
            process.AddTemplate("PH-XFER", "转移出料", StepType.Transfer, Isa88.DefaultOperation(StepType.Transfer), 60,
            [
                Spec(0, "转移量", "kg", 50, 1, 500, true, true, true),
                Spec(1, "转移时长", "s", 5, 1, 300, true, false)
            ]);

            var generic = new EquipmentClass("GENERIC", "通用环回站", "实验室环回允许全部写 PLC 相类型。");
            foreach (var t in furnace.Templates.Concat(process.Templates).ToList())
                generic.AddTemplate("GEN-" + t.Code, t.Name, t.StepType, t.Operation, t.WatchdogSeconds, t.Parameters());

            db.EquipmentClasses.AddRange(furnace, quench, process, generic);
            await db.SaveChangesAsync(ct);
        }

        async Task AssignAsync(string equipmentCode, string classCode)
        {
            var row = await db.Equipment.FirstOrDefaultAsync(e => e.Code == equipmentCode, ct);
            if (row is not null && string.IsNullOrWhiteSpace(row.EquipmentClassCode))
                row.AssignClass(classCode);
        }

        await AssignAsync("HT-01", "FURNACE");
        await AssignAsync("HT-02", "QUENCH");
        await AssignAsync("MB-01", "GENERIC");
        await AssignAsync("S7-01", "GENERIC");
        await AssignAsync("UA-01", "GENERIC");
        await db.SaveChangesAsync(ct);
    }

    private static async Task EnsureDemoLotsAsync(AppDbContext db, CancellationToken ct)
    {
        if (await db.MaterialLots.AnyAsync(ct))
            return;
        db.MaterialLots.Add(MaterialLot.Receive("INGOT-DEMO-01", "AL6061", "铝合金锭", 250, "kg"));
        await db.SaveChangesAsync(ct);
    }

    private static async Task EnsureModbusLoopbackAsync(AppDbContext db, CancellationToken ct)
    {
        if (await db.Equipment.AnyAsync(e => e.Code == ModbusLoopbackHostedService.EquipmentCode, ct))
            return;
        var map = JsonSerializer.Serialize(HandshakeTagMap.ModbusLoopback());
        db.Equipment.Add(new EquipmentLine(
            ModbusLoopbackHostedService.EquipmentCode,
            "Modbus 环回从站",
            PlcProtocol.ModbusTcp,
            "127.0.0.1",
            ModbusLoopbackHostedService.DefaultPort,
            "MODBUS",
            0,
            1,
            map,
            "本机 IOTClient Modbus TCP 四步握手从站，用于协议栈联调。连接测试只读，禁止盲写。"));
        await db.SaveChangesAsync(ct);
    }

    private static async Task EnsureOpcUaLoopbackAsync(AppDbContext db, CancellationToken ct)
    {
        if (await db.Equipment.AnyAsync(e => e.Code == OpcUaLoopbackHostedService.EquipmentCode, ct))
            return;
        var map = JsonSerializer.Serialize(HandshakeTagMap.OpcUaLoopback());
        db.Equipment.Add(new EquipmentLine(
            OpcUaLoopbackHostedService.EquipmentCode,
            "OPC UA 环回从站",
            PlcProtocol.OpcUa,
            $"opc.tcp://127.0.0.1:{OpcUaLoopbackHostedService.DefaultPort}{OpcUaHandshakeSlave.PathSuffix}",
            OpcUaLoopbackHostedService.DefaultPort,
            "OPC_UA",
            0,
            1,
            map,
            "本机 OPC Foundation 四步握手从站，用于 OPC UA 协议栈联调。连接测试只读，禁止盲写。实验室自动接受自签证书。"));
        await db.SaveChangesAsync(ct);
    }

    private static async Task EnsureSiemensLoopbackAsync(AppDbContext db, CancellationToken ct)
    {
        if (await db.Equipment.AnyAsync(e => e.Code == SiemensS7LoopbackHostedService.EquipmentCode, ct))
            return;
        var map = JsonSerializer.Serialize(new HandshakeTagMap());
        db.Equipment.Add(new EquipmentLine(
            SiemensS7LoopbackHostedService.EquipmentCode,
            "S7 环回从站",
            PlcProtocol.SiemensS7,
            "127.0.0.1",
            SiemensS7LoopbackHostedService.DefaultPort,
            "S7_1200",
            0,
            1,
            map,
            "本机 IOTClient Siemens S7 ISO-on-TCP 四步握手从站，DB10 默认点表。连接测试只读，禁止盲写。"));
        await db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// 第二套仿真炉 + 双 Unit Procedure 示范配方（固溶/淬火可并行，汇合质检）。
    /// 对已有库幂等：按设备编码与配方编码补齐。
    /// </summary>
    private static async Task EnsureParallelDemoAsync(AppDbContext db, CancellationToken ct)
    {
        var tagMap = JsonSerializer.Serialize(new HandshakeTagMap());
        if (!await db.Equipment.AnyAsync(e => e.Code == "HT-02", ct))
        {
            db.Equipment.Add(new EquipmentLine(
                "HT-02", "2# 淬火槽", PlcProtocol.Simulator, "127.0.0.1", 102,
                "S7_1200", 0, 1, tagMap, "第二套进程内 PLC 仿真器，用于 ISA-88 单元并行握手。"));
            await db.SaveChangesAsync(ct);
        }

        if (await db.Recipes.AnyAsync(r => r.Code == "AL-HT-2UP", ct))
            return;

        var engineer = await db.Users.SingleAsync(u => u.UserName == "engineer", ct);
        var supervisor = await db.Users.SingleAsync(u => u.UserName == "supervisor", ct);
        var qa = await db.Users.SingleAsync(u => u.UserName == "qa", ct);

        var recipe = MasterRecipe.Create("AL-HT-2UP", "Al-6061 双单元热处理", "AL6061", "铝合金 6061 锻件",
            "UP-固溶 与 UP-淬火 无互为前驱，可绑定不同 PLC 并行握手；完成后汇合 UP-QC。", engineer.Id);
        var draft = recipe.RequireDraft();

        var s10 = Phase("S10", "升温至固溶温度", StepType.Heat, 0, 80, 80, 180, "UP-固溶",
            P(0, "目标温度", "℃", 530, 520, 540, true, true),
            P(1, "升温斜率", "℃/min", 8, 4, 12, true, false));
        var s20 = Phase("S20", "固溶保温", StepType.Hold, 1, 80, 280, 200, "UP-固溶",
            P(0, "保温温度", "℃", 530, 525, 535, true, true),
            P(1, "保温时长", "s", 8, 1, 3600, true, true));
        var s30 = Phase("S30", "淬火冷却", StepType.Cool, 2, 520, 180, 120, "UP-淬火",
            P(0, "终点温度", "℃", 40, 20, 60, true, true),
            P(1, "冷却时长", "s", 6, 1, 600, true, false));
        var s40 = Phase("S40", "汇合质检采样", StepType.QualityCheck, 3, 300, 480, 60, "UP-QC",
            P(0, "硬度下限", "HB", 95, 90, 110, false, true));

        draft.ReplaceProcedure(
            [s10, s20, s30, s40],
            [
                new RecipeEdge(draft.Id, s10.Id, s20.Id),
                new RecipeEdge(draft.Id, s20.Id, s40.Id),
                new RecipeEdge(draft.Id, s30.Id, s40.Id)
            ]);
        draft.Submit(DateTimeOffset.UtcNow.AddMinutes(-6), engineer.Id, engineer.DisplayName, "提交双单元并行示范配方");
        draft.Decide(ApprovalLevel.Supervisor, supervisor.Id, supervisor.DisplayName, ApprovalDecision.Approved, "单元边界与汇合点正确", DateTimeOffset.UtcNow.AddMinutes(-4));
        draft.Decide(ApprovalLevel.Quality, qa.Id, qa.DisplayName, ApprovalDecision.Approved, "并行握手不改变质检归档", DateTimeOffset.UtcNow.AddMinutes(-2));
        recipe.MarkApproved(draft);
        db.Recipes.Add(recipe);
        await db.SaveChangesAsync(ct);

        RecipeStep Phase(string code, string name, StepType type, int ordinal, double x, double y, int watchdog, string unit, params RecipeParameter[] parameters) =>
            new(draft.Id, code, name, type, ordinal, x, y, watchdog, null, parameters, null, unit, Isa88.DefaultOperation(type));

        static RecipeParameter P(int slot, string name, string unit, double sp, double min, double max, bool write, bool qc) =>
            new(slot, name, unit, sp, min, max, write, qc);
    }

    /// <summary>
    /// 人工确认（禁止写 PLC）与质检超差保持示范配方。对已有库按编码幂等补齐。
    /// </summary>
    private static async Task EnsureConfirmAndOosDemoAsync(AppDbContext db, CancellationToken ct)
    {
        var engineer = await db.Users.SingleAsync(u => u.UserName == "engineer", ct);
        var supervisor = await db.Users.SingleAsync(u => u.UserName == "supervisor", ct);
        var qa = await db.Users.SingleAsync(u => u.UserName == "qa", ct);

        if (!await db.Recipes.AnyAsync(r => r.Code == "AL-HT-CFM", ct))
        {
            var recipe = MasterRecipe.Create("AL-HT-CFM", "人工确认闭环示范", "AL6061", "铝合金 6061 锻件",
                "升温完成后进入 ManualConfirm，调度 Idle PLC，等待电子签名，禁止 Trigger_Write。", engineer.Id);
            var draft = recipe.RequireDraft();
            var s10 = new RecipeStep(draft.Id, "S10", "升温至确认点", StepType.Heat, 0, 80, 120, 60, null,
                [P(0, "目标温度", "℃", 120, 100, 200, true, true),
                 P(1, "时长", "s", 1, 0.5, 5, true, true)],
                null, Isa88.DefaultUnitProcedure, Isa88.DefaultOperation(StepType.Heat));
            var s20 = new RecipeStep(draft.Id, "S20", "操作员确认", StepType.ManualConfirm, 1, 360, 120, 120, null,
                [P(0, "确认意见", "", 0, null, null, false, false)],
                null, Isa88.DefaultUnitProcedure, Isa88.DefaultOperation(StepType.ManualConfirm));
            draft.ReplaceProcedure([s10, s20], [new RecipeEdge(draft.Id, s10.Id, s20.Id)]);
            draft.Submit(DateTimeOffset.UtcNow.AddMinutes(-4), engineer.Id, engineer.DisplayName, "提交人工确认示范");
            draft.Decide(ApprovalLevel.Supervisor, supervisor.Id, supervisor.DisplayName, ApprovalDecision.Approved, "确认工步不写 PLC", DateTimeOffset.UtcNow.AddMinutes(-3));
            draft.Decide(ApprovalLevel.Quality, qa.Id, qa.DisplayName, ApprovalDecision.Approved, "电子签名放行", DateTimeOffset.UtcNow.AddMinutes(-2));
            recipe.MarkApproved(draft);
            db.Recipes.Add(recipe);
            await db.SaveChangesAsync(ct);
        }

        if (!await db.Recipes.AnyAsync(r => r.Code == "AL-HT-OOS", ct))
        {
            var recipe = MasterRecipe.Create("AL-HT-OOS", "质检超差保持示范", "AL6061", "铝合金 6061 锻件",
                "归档温度故意超出规格，握手 D 后 QualityOos 保持，禁止写下一步。", engineer.Id);
            var draft = recipe.RequireDraft();
            var s10 = new RecipeStep(draft.Id, "S10", "升温（规格故意过窄）", StepType.Heat, 0, 80, 120, 60, null,
                [P(0, "目标温度", "℃", 120, 200, 300, true, true),
                 P(1, "时长", "s", 1, 0.5, 5, true, true)],
                null, Isa88.DefaultUnitProcedure, Isa88.DefaultOperation(StepType.Heat));
            var s20 = new RecipeStep(draft.Id, "S20", "保温（超差后不应写入）", StepType.Hold, 1, 360, 120, 60, null,
                [P(0, "保温温度", "℃", 120, 100, 200, true, true),
                 P(1, "保温时长", "s", 1, 0.5, 5, true, true)],
                null, Isa88.DefaultUnitProcedure, Isa88.DefaultOperation(StepType.Hold));
            draft.ReplaceProcedure([s10, s20], [new RecipeEdge(draft.Id, s10.Id, s20.Id)]);
            draft.Submit(DateTimeOffset.UtcNow.AddMinutes(-4), engineer.Id, engineer.DisplayName, "提交超差保持示范");
            draft.Decide(ApprovalLevel.Supervisor, supervisor.Id, supervisor.DisplayName, ApprovalDecision.Approved, "超差必须保持", DateTimeOffset.UtcNow.AddMinutes(-3));
            draft.Decide(ApprovalLevel.Quality, qa.Id, qa.DisplayName, ApprovalDecision.Approved, "QualityOos 后由质量恢复", DateTimeOffset.UtcNow.AddMinutes(-2));
            recipe.MarkApproved(draft);
            db.Recipes.Add(recipe);
            await db.SaveChangesAsync(ct);
        }

        static RecipeParameter P(int slot, string name, string unit, double sp, double? min, double? max, bool write, bool qc) =>
            new(slot, name, unit, sp, min, max, write, qc);
    }

    /// <summary>
    /// Wait（禁止写 PLC，保持后续跑剩余）与 Mix/Pressure/Transfer 四步握手示范。
    /// </summary>
    private static async Task EnsureWaitAndProcessOpsDemoAsync(AppDbContext db, CancellationToken ct)
    {
        var engineer = await db.Users.SingleAsync(u => u.UserName == "engineer", ct);
        var supervisor = await db.Users.SingleAsync(u => u.UserName == "supervisor", ct);
        var qa = await db.Users.SingleAsync(u => u.UserName == "qa", ct);

        if (!await db.Recipes.AnyAsync(r => r.Code == "AL-HT-WAIT", ct))
        {
            var recipe = MasterRecipe.Create("AL-HT-WAIT", "上位机等待剩余时长示范", "AL6061", "铝合金 6061 锻件",
                "Heat 后 Wait 不写 PLC。保持时归档剩余秒数，恢复后续跑剩余，禁止整段重跑。", engineer.Id);
            var draft = recipe.RequireDraft();
            var s10 = new RecipeStep(draft.Id, "S10", "升温至等待点", StepType.Heat, 0, 80, 120, 60, null,
                [P(0, "目标温度", "℃", 120, 100, 200, true, true),
                 P(1, "时长", "s", 1, 0.5, 5, true, true)],
                null, Isa88.DefaultUnitProcedure, Isa88.DefaultOperation(StepType.Heat));
            var s20 = new RecipeStep(draft.Id, "S20", "上位机等待", StepType.Wait, 1, 360, 120, 120, null,
                [P(0, "等待时长", "s", 8, 1, 60, false, false)],
                null, Isa88.DefaultUnitProcedure, Isa88.DefaultOperation(StepType.Wait));
            draft.ReplaceProcedure([s10, s20], [new RecipeEdge(draft.Id, s10.Id, s20.Id)]);
            draft.Submit(DateTimeOffset.UtcNow.AddMinutes(-4), engineer.Id, engineer.DisplayName, "提交等待剩余示范");
            draft.Decide(ApprovalLevel.Supervisor, supervisor.Id, supervisor.DisplayName, ApprovalDecision.Approved, "Wait 不写 PLC", DateTimeOffset.UtcNow.AddMinutes(-3));
            draft.Decide(ApprovalLevel.Quality, qa.Id, qa.DisplayName, ApprovalDecision.Approved, "保持后续跑剩余", DateTimeOffset.UtcNow.AddMinutes(-2));
            recipe.MarkApproved(draft);
            db.Recipes.Add(recipe);
            await db.SaveChangesAsync(ct);
        }

        if (!await db.Recipes.AnyAsync(r => r.Code == "AL-PR-OPS", ct))
        {
            var recipe = MasterRecipe.Create("AL-PR-OPS", "搅拌加压转移示范", "AL6061", "铝合金 6061 锻件",
                "Mix / Pressure / Transfer 走四步握手写 PLC，汇合 QualityCheck 禁止写 PLC。", engineer.Id);
            var draft = recipe.RequireDraft();
            var s10 = new RecipeStep(draft.Id, "S10", "搅拌混合", StepType.Mix, 0, 80, 80, 60, null,
                [P(0, "搅拌转速", "rpm", 60, 10, 200, true, false),
                 P(1, "搅拌时长", "s", 1, 0.5, 60, true, true)],
                null, "UP-混合", Isa88.DefaultOperation(StepType.Mix));
            var s20 = new RecipeStep(draft.Id, "S20", "加压保压", StepType.Pressure, 1, 290, 80, 60, null,
                [P(0, "目标压力", "bar", 2.5, 1, 6, true, true),
                 P(1, "保压时长", "s", 1, 0.5, 60, true, false)],
                null, "UP-加压", Isa88.DefaultOperation(StepType.Pressure));
            var s30 = new RecipeStep(draft.Id, "S30", "转移出料", StepType.Transfer, 2, 500, 80, 60, null,
                [P(0, "转移量", "kg", 50, 1, 500, true, true, true),
                 P(1, "转移时长", "s", 1, 0.5, 60, true, false)],
                null, "UP-转移", Isa88.DefaultOperation(StepType.Transfer));
            var s40 = new RecipeStep(draft.Id, "S40", "质检采样", StepType.QualityCheck, 3, 710, 80, 60, null,
                [P(0, "硬度下限", "HB", 95, 90, 110, false, true)],
                null, "UP-QC", Isa88.DefaultOperation(StepType.QualityCheck));
            draft.ReplaceProcedure(
                [s10, s20, s30, s40],
                [
                    new RecipeEdge(draft.Id, s10.Id, s20.Id),
                    new RecipeEdge(draft.Id, s20.Id, s30.Id),
                    new RecipeEdge(draft.Id, s30.Id, s40.Id)
                ]);
            draft.Submit(DateTimeOffset.UtcNow.AddMinutes(-5), engineer.Id, engineer.DisplayName, "提交搅拌加压转移示范");
            draft.Decide(ApprovalLevel.Supervisor, supervisor.Id, supervisor.DisplayName, ApprovalDecision.Approved, "工艺路径与单元边界正确", DateTimeOffset.UtcNow.AddMinutes(-4));
            draft.Decide(ApprovalLevel.Quality, qa.Id, qa.DisplayName, ApprovalDecision.Approved, "质检不写 PLC", DateTimeOffset.UtcNow.AddMinutes(-2));
            recipe.MarkApproved(draft);
            db.Recipes.Add(recipe);
            await db.SaveChangesAsync(ct);
        }

        static RecipeParameter P(int slot, string name, string unit, double sp, double? min, double? max, bool write, bool qc, bool scale = false) =>
            new(slot, name, unit, sp, min, max, write, qc, scale);
    }

    /// <summary>
    /// 已批准 Heat 工步若只有斜率没有时长，补升温时长（不写 PLC），避免仿真把斜率当工艺秒数。
    /// </summary>
    private static async Task RepairHeatProcessDurationAsync(AppDbContext db, CancellationToken ct)
    {
        var steps = await db.RecipeSteps.Include(s => s.Parameters)
            .Where(s => s.Type == StepType.Heat)
            .ToListAsync(ct);
        var changed = false;
        foreach (var step in steps)
        {
            if (step.Parameters.Any(HasDurationParam))
                continue;
            var used = step.Parameters.Select(p => p.SlotIndex).ToHashSet();
            var slot = Enumerable.Range(0, RecipeParameter.MaxSlots).FirstOrDefault(i => !used.Contains(i));
            if (used.Contains(slot))
                continue;
            var ramp = step.Parameters.FirstOrDefault(p =>
                p.Name.Contains("斜率", StringComparison.Ordinal) ||
                p.Name.Contains("ramp", StringComparison.OrdinalIgnoreCase));
            var seconds = ramp is { Setpoint: > 0.4 and < 120 } ? ramp.Setpoint : 8;
            step.AddParameter(new RecipeParameter(slot, "升温时长", "s", seconds, 0.5, 3600, false, false));
            changed = true;
        }

        if (changed)
            await db.SaveChangesAsync(ct);

        static bool HasDurationParam(RecipeParameter p)
        {
            var name = p.Name ?? "";
            var unit = p.EngineeringUnit ?? "";
            if (name.Contains("斜率", StringComparison.Ordinal) || name.Contains("ramp", StringComparison.OrdinalIgnoreCase) || unit.Contains('/'))
                return false;
            return unit.Equals("s", StringComparison.OrdinalIgnoreCase) ||
                   unit.Equals("sec", StringComparison.OrdinalIgnoreCase) ||
                   unit.Equals("min", StringComparison.OrdinalIgnoreCase) ||
                   unit.Equals("h", StringComparison.OrdinalIgnoreCase) ||
                   unit.Equals("hr", StringComparison.OrdinalIgnoreCase) ||
                   name.Contains("时长", StringComparison.Ordinal) ||
                   name.Contains("时间", StringComparison.Ordinal) ||
                   name.Contains("等待", StringComparison.Ordinal);
        }
    }

    private static async Task RepairIsa88Async(AppDbContext db, CancellationToken ct)
    {
        var steps = await db.RecipeSteps.ToListAsync(ct);
        foreach (var step in steps)
            step.EnsureIsa88();
        await db.SaveChangesAsync(ct);
    }

    private static async Task RepairMojibakeAsync(AppDbContext db, CancellationToken ct)
    {
        var recipes = await db.Recipes
            .Include(r => r.Versions).ThenInclude(v => v.Steps).ThenInclude(s => s.Parameters)
            .AsSplitQuery()
            .ToListAsync(ct);

        foreach (var recipe in recipes)
        {
            foreach (var version in recipe.Versions)
            {
                foreach (var step in version.Steps)
                {
                    foreach (var parameter in step.Parameters)
                        parameter.RestoreRateUnitIfCorrupted();
                }
            }

            var source = recipe.Versions.OrderBy(v => v.VersionNumber).FirstOrDefault();
            if (source is null)
                continue;

            var sourceSteps = source.Steps.ToDictionary(s => s.Code, StringComparer.OrdinalIgnoreCase);
            foreach (var version in recipe.Versions.Where(v => v.Id != source.Id))
            {
                foreach (var step in version.Steps)
                {
                    if (!sourceSteps.TryGetValue(step.Code, out var from))
                        continue;
                    step.RestoreIfMojibake(from.Name, from.Description);
                    var fromParams = from.Parameters.ToDictionary(p => p.SlotIndex);
                    foreach (var parameter in step.Parameters)
                    {
                        if (fromParams.TryGetValue(parameter.SlotIndex, out var original))
                            parameter.RestoreIfMojibake(original.Name, original.EngineeringUnit);
                    }
                }
            }
        }

        await db.SaveChangesAsync(ct);
    }

    private static async Task RepairHoldTagsAsync(AppDbContext db, CancellationToken ct)
    {
        var rows = await db.Equipment.ToListAsync(ct);
        var changed = false;
        foreach (var equipment in rows)
        {
            HandshakeTagMap map;
            try
            {
                map = JsonSerializer.Deserialize<HandshakeTagMap>(equipment.TagMapJson,
                          new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
                      ?? new HandshakeTagMap();
            }
            catch
            {
                continue;
            }

            var looksLikeS7 = !string.IsNullOrWhiteSpace(map.HostHold) &&
                              map.HostHold.StartsWith("DB", StringComparison.OrdinalIgnoreCase);
            if (equipment.Protocol == PlcProtocol.ModbusTcp &&
                (string.IsNullOrWhiteSpace(map.HostHold) || looksLikeS7))
            {
                var loop = HandshakeTagMap.ModbusLoopback();
                map.HostHold = loop.HostHold;
                map.PlcHeld = loop.PlcHeld;
            }
            else if (equipment.Protocol == PlcProtocol.OpcUa &&
                     (string.IsNullOrWhiteSpace(map.HostHold) || looksLikeS7))
            {
                var loop = HandshakeTagMap.OpcUaLoopback();
                map.HostHold = loop.HostHold;
                map.PlcHeld = loop.PlcHeld;
            }
            else if (string.IsNullOrWhiteSpace(map.HostHold))
            {
                map.HostHold = "DB10.8.5";
                map.PlcHeld = "DB10.8.6";
            }
            else
                continue;

            equipment.ReplaceTagMap(JsonSerializer.Serialize(map));
            changed = true;
        }

        if (changed)
            await db.SaveChangesAsync(ct);
    }
}
