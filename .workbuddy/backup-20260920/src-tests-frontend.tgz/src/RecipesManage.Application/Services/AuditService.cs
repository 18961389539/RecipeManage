using Microsoft.EntityFrameworkCore;
using RecipesManage.Application.Contracts;
using RecipesManage.Application.Dtos;
using RecipesManage.Domain.Identity;

namespace RecipesManage.Application.Services;

public sealed class AuditService(IAppDbContext db)
{
    public async Task<IReadOnlyList<AuditLogDto>> QueryAsync(
        string? entityType,
        string? entityId,
        int take,
        CancellationToken ct)
    {
        take = Math.Clamp(take <= 0 ? 200 : take, 1, 500);
        var query = db.AuditLogs.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(entityType))
            query = query.Where(x => x.EntityType == entityType);
        if (!string.IsNullOrWhiteSpace(entityId))
            query = query.Where(x => x.EntityId == entityId);

        var rows = await query.ToListAsync(ct);
        return rows
            .OrderByDescending(x => x.At)
            .Take(take)
            .Select(x => new AuditLogDto(x.Id, x.UserName, x.Action, x.EntityType, x.EntityId, x.Detail, x.At))
            .ToList();
    }
}
