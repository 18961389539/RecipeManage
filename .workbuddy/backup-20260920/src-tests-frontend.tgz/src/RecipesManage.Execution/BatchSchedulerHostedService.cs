﻿using System.Collections.Concurrent;
using System.Text.Json;
using System.Threading.Channels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RecipesManage.Application.Contracts;
using RecipesManage.Application.Services;
using RecipesManage.Domain.Batches;
using RecipesManage.Domain.Handshake;
using RecipesManage.Domain.Identity;
using RecipesManage.Domain.Recipes;
using RecipesManage.Infrastructure.Persistence;

namespace RecipesManage.Execution;

public abstract record SchedulerCommand;
public sealed record StartBatchCommand(Guid BatchId) : SchedulerCommand;
public sealed record AbortBatchCommand(Guid BatchId, string Reason) : SchedulerCommand;
public sealed record HoldBatchCommand(Guid BatchId, string Reason) : SchedulerCommand;
public sealed record SkipStepCommand(Guid BatchId, string Reason, Guid? StepId) : SchedulerCommand;
public sealed record ConfirmStepCommand(Guid BatchId, string Comment, Guid? StepId) : SchedulerCommand;

public sealed partial class BatchSchedulerHostedService : BackgroundService, IBatchScheduler
{
    private readonly Channel<SchedulerCommand> _channel = Channel.CreateUnbounded<SchedulerCommand>(
        new UnboundedChannelOptions { SingleReader = true });
    private readonly Dictionary<Guid, CancellationTokenSource> _sessions = [];
    private readonly ConcurrentDictionary<Guid, string> _holdReasons = new();
    private readonly ConcurrentDictionary<Guid, SkipRequest> _skipRequests = new();
    private readonly ConcurrentDictionary<Guid, ConfirmRequest> _confirmRequests = new();
    private readonly IServiceScopeFactory _scopes;
    private readonly IPlcDriverFactory _drivers;
    private readonly IExecutionPublisher _publisher;
    private readonly ILogger<BatchSchedulerHostedService> _log;

    public BatchSchedulerHostedService(
        IServiceScopeFactory scopes,
        IPlcDriverFactory drivers,
        IExecutionPublisher publisher,
        ILogger<BatchSchedulerHostedService> log)
    {
        _scopes = scopes;
        _drivers = drivers;
        _publisher = publisher;
        _log = log;
    }

    public ValueTask EnqueueStartAsync(Guid batchId, CancellationToken cancellationToken = default) =>
        _channel.Writer.WriteAsync(new StartBatchCommand(batchId), cancellationToken);

    public ValueTask EnqueueAbortAsync(Guid batchId, string reason, CancellationToken cancellationToken = default) =>
        _channel.Writer.WriteAsync(new AbortBatchCommand(batchId, reason), cancellationToken);

    public ValueTask EnqueueHoldAsync(Guid batchId, string reason, CancellationToken cancellationToken = default) =>
        _channel.Writer.WriteAsync(new HoldBatchCommand(batchId, reason), cancellationToken);

    public ValueTask EnqueueSkipAsync(Guid batchId, string reason, Guid? stepId = null, CancellationToken cancellationToken = default) =>
        _channel.Writer.WriteAsync(new SkipStepCommand(batchId, reason, stepId), cancellationToken);

    public ValueTask EnqueueConfirmAsync(Guid batchId, string comment, Guid? stepId = null, CancellationToken cancellationToken = default) =>
        _channel.Writer.WriteAsync(new ConfirmStepCommand(batchId, comment, stepId), cancellationToken);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await RecoverRunningAsync(stoppingToken);

        await foreach (var command in _channel.Reader.ReadAllAsync(stoppingToken))
        {
            switch (command)
            {
                case StartBatchCommand start:
                    _holdReasons.TryRemove(start.BatchId, out _);
                    _skipRequests.TryRemove(start.BatchId, out _);
                    StartSession(start.BatchId, stoppingToken);
                    break;
                case ConfirmStepCommand confirm:
                    _confirmRequests[confirm.BatchId] = new ConfirmRequest(confirm.Comment, confirm.StepId);
                    break;
                case HoldBatchCommand hold:
                    _holdReasons[hold.BatchId] = hold.Reason;
                    break;
                case SkipStepCommand skip:
                    _skipRequests[skip.BatchId] = new SkipRequest(skip.Reason, skip.StepId);
                    break;
                case AbortBatchCommand abort:
                    _holdReasons.TryRemove(abort.BatchId, out _);
                    _skipRequests.TryRemove(abort.BatchId, out _);
                    _confirmRequests.TryRemove(abort.BatchId, out _);
                    if (_sessions.Remove(abort.BatchId, out var cts))
                    {
                        cts.Cancel();
                        cts.Dispose();
                    }
                    await MarkAbortedAsync(abort.BatchId, abort.Reason, stoppingToken);
                    break;
            }
        }
    }

    private void StartSession(Guid batchId, CancellationToken hostCt)
    {
        if (_sessions.ContainsKey(batchId))
            return;

        var cts = CancellationTokenSource.CreateLinkedTokenSource(hostCt);
        _sessions[batchId] = cts;
        _ = Task.Run(async () =>
        {
            try
            {
                await RunBatchAsync(batchId, cts.Token);
            }
            catch (OperationCanceledException) when (cts.IsCancellationRequested)
            {
                _log.LogInformation("批次 {BatchId} 会话已取消", batchId);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "批次 {BatchId} 调度异常", batchId);
                await MarkFaultAsync(batchId, "ENGINE", ex.Message, CancellationToken.None);
            }
            finally
            {
                _sessions.Remove(batchId);
                _skipRequests.TryRemove(batchId, out _);
                _confirmRequests.TryRemove(batchId, out _);
                cts.Dispose();
            }
        }, cts.Token);
    }

    private async Task RecoverRunningAsync(CancellationToken ct)
    {
        using var scope = _scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var running = await db.Batches
            .Where(b => b.Status == BatchStatus.Running || b.Status == BatchStatus.Queued)
            .Select(b => b.Id)
            .ToListAsync(ct);
        foreach (var id in running)
            await _channel.Writer.WriteAsync(new StartBatchCommand(id), ct);
    }

    private Task RunBatchAsync(Guid batchId, CancellationToken ct) => RunUnitWavesAsync(batchId, ct);

    private static async Task ApplyAsync(
        HandshakeAction action,
        HandshakeStateMachine machine,
        IPlcHandshakeClient plc,
        AppDbContext db,
        ProductionBatch batch,
        BatchStepExecution exec,
        SnapshotStep step,
        HandshakeWorkContext work,
        DateTimeOffset now,
        SemaphoreSlim gate,
        string? equipmentCode,
        CancellationToken ct)
    {
        switch (action)
        {
            case WriteStepPayloadAction write:
                await plc.WriteStepPayloadAsync(write.StepId, write.StepType, write.Parameters, ct);
                var echo = await plc.ReadStepPayloadAsync(ct);
                await LockedAsync(gate, ct, () =>
                {
                    if (!PlcWriteVerify.Matches(write.StepId, write.StepType, write.Parameters, echo, out var mismatch))
                    {
                        machine.NotifyWriteVerifyFailed(now, mismatch);
                        RecordHandshake(db, batch, step, machine, work, now, "verify", mismatch, equipmentCode);
                        return Task.CompletedTask;
                    }

                    machine.NotifyParametersWritten(now);
                    RecordHandshake(db, batch, step, machine, work, now, "write",
                        $"Step_ID={write.StepId} Step_Type={write.StepType}", equipmentCode);
                    RecordHandshake(db, batch, step, machine, work, now, "verify",
                        $"回读 Step_ID={echo.StepId} Param[0]={echo.Parameters.ElementAtOrDefault(0)} 一致", equipmentCode);
                    return Task.CompletedTask;
                });
                break;
            case AssertTriggerWriteAction trigger:
                if (trigger.Value && machine.Phase != HandshakePhase.AwaitingPlcAck)
                {
                    await LockedAsync(gate, ct, () =>
                    {
                        machine.NotifyTriggerAsserted();
                        RecordHandshake(db, batch, step, machine, work, now, "fault", machine.Fault?.Message, equipmentCode);
                        return Task.CompletedTask;
                    });
                    break;
                }
                await plc.SetTriggerWriteAsync(trigger.Value, ct);
                await LockedAsync(gate, ct, () =>
                {
                    if (trigger.Value)
                        machine.NotifyTriggerAsserted();
                    RecordHandshake(db, batch, step, machine, work, now, "trigger", trigger.Value ? "Trigger_Write=1" : "Trigger_Write=0", equipmentCode);
                    return Task.CompletedTask;
                });
                break;
            case ArchiveMeasurementsAction:
                var measured = await plc.ReadMeasuredAsync(ct);
                await LockedAsync(gate, ct, () =>
                {
                    foreach (var (tag, value) in measured)
                        db.ProcessSamples.Add(new ProcessSample(batch.Id, step.StepId, now, tag, value, "archive"));
                    var quality = JsonSerializer.Serialize(QualityArchive.Bind(step, measured), BatchService.JsonOptions);
                    exec.MarkCompleted(now, quality);
                    machine.NotifyArchiveCompleted();
                    RecordHandshake(db, batch, step, machine, work, now, "archive", "Step_Complete 归档实测", equipmentCode);
                    return Task.CompletedTask;
                });
                break;
            case ResetCompleteAction:
                await plc.ResetCompleteAsync(ct);
                await LockedAsync(gate, ct, () =>
                {
                    machine.NotifyResetIssued();
                    RecordHandshake(db, batch, step, machine, work, now, "reset", "复位 Step_Complete", equipmentCode);
                    return Task.CompletedTask;
                });
                break;
            case AdvanceStepAction:
                await LockedAsync(gate, ct, () =>
                {
                    RecordHandshake(db, batch, step, machine, work, now, "advance", "允许下一步，禁止盲写", equipmentCode);
                    return Task.CompletedTask;
                });
                break;
            case RaiseFaultAction fault:
                await LockedAsync(gate, ct, () =>
                {
                    RecordHandshake(db, batch, step, machine, work, now, "fault", fault.Fault.Message, equipmentCode);
                    return Task.CompletedTask;
                });
                break;
        }
    }

    private static void RecordHandshake(
        AppDbContext db,
        ProductionBatch batch,
        SnapshotStep step,
        HandshakeStateMachine machine,
        HandshakeWorkContext work,
        DateTimeOffset now,
        string kind,
        string? detail,
        string? equipmentCode = null)
    {
        var tagged = string.IsNullOrWhiteSpace(equipmentCode) || string.IsNullOrWhiteSpace(detail)
            ? detail
            : $"[{equipmentCode}] {detail}";
        db.HandshakeEvents.Add(new HandshakeEvent(
            batch.Id, step.StepId, step.Code, machine.Phase.ToString(), kind, tagged,
            machine.RemainingSeconds(work, now)));
    }

    private bool TryConsumeSkip(Guid batchId, Guid stepId, out string reason)
    {
        reason = "";
        if (!_skipRequests.TryGetValue(batchId, out var request))
            return false;
        if (request.StepId is Guid target && target != stepId)
            return false;
        if (!_skipRequests.TryRemove(batchId, out request))
            return false;
        reason = request.Reason;
        return true;
    }

    private bool TryConsumeConfirm(Guid batchId, Guid stepId, out string comment)
    {
        comment = "";
        if (!_confirmRequests.TryGetValue(batchId, out var request))
            return false;
        if (request.StepId is Guid target && target != stepId)
            return false;
        if (!_confirmRequests.TryRemove(batchId, out request))
            return false;
        comment = request.Comment;
        return true;
    }

    private readonly record struct SkipRequest(string Reason, Guid? StepId);
    private readonly record struct ConfirmRequest(string Comment, Guid? StepId);

    private static async Task IdlePlcAsync(IPlcHandshakeClient plc, CancellationToken ct)
    {
        try
        {
            await plc.SetHostHoldAsync(false, ct);
            await plc.SetTriggerWriteAsync(false, ct);
            await plc.ResetCompleteAsync(ct);
        }
        catch
        {
            // 保持/中止时尽量复位握手位，通讯失败不覆盖批次状态。
        }
    }

    private async Task IdleEquipmentAsync(Guid equipmentId, CancellationToken ct)
    {
        using var scope = _scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var equipment = await db.Equipment.FirstOrDefaultAsync(e => e.Id == equipmentId, ct);
        if (equipment is null) return;
        try
        {
            await using var plc = _drivers.Create(equipment);
            await plc.ConnectAsync(ct);
            await IdlePlcAsync(plc, ct);
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "中止后复位设备 {EquipmentId} 握手位失败", equipmentId);
        }
    }

    private async Task MarkFaultAsync(Guid batchId, string code, string message, CancellationToken ct)
    {
        using var scope = _scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var batch = await db.Batches.Include(b => b.StepExecutions).FirstOrDefaultAsync(b => b.Id == batchId, ct);
        if (batch is null) return;
        batch.Fault(code, message);
        var stepCode = batch.StepExecutions.FirstOrDefault(s => s.StepId == batch.CurrentStepId)?.StepCode ?? "";
        db.ProcessAlarms.Add(new ProcessAlarm(batch.Id, batch.BatchNo, batch.CurrentStepId, stepCode, code, "Fault", message, DateTimeOffset.UtcNow));
        await db.SaveChangesAsync(ct);
        await _publisher.PublishAsync(new ExecutionEvent(batchId, "fault", new { code, message }), ct);
        await _publisher.PublishAsync(new ExecutionEvent(batchId, "alarm", new
        {
            code,
            message,
            stepCode,
            severity = "Fault"
        }), ct);
        await OccupancyRealtime.PublishAsync(db, _publisher, batchId, ct);
    }

    private async Task MarkAbortedAsync(Guid batchId, string reason, CancellationToken ct)
    {
        using var scope = _scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var batch = await db.Batches.FirstOrDefaultAsync(b => b.Id == batchId, ct);
        if (batch is null) return;
        if (batch.Status is not BatchStatus.Completed and not BatchStatus.Aborted)
        {
            batch.Abort(reason);
            await db.SaveChangesAsync(ct);
            await _publisher.PublishAsync(new ExecutionEvent(batchId, "aborted", new { reason }), ct);
            await OccupancyRealtime.PublishAsync(db, _publisher, batchId, ct);
        }

        var snapshot = BatchService.Deserialize(batch.ControlRecipeJson);
        foreach (var equipmentId in UnitEquipmentBinding.AllIds(snapshot, batch.EquipmentId))
            await IdleEquipmentAsync(equipmentId, ct);
    }
}
