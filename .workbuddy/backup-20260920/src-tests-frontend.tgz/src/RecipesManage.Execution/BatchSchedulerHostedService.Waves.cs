using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RecipesManage.Application.Contracts;
using RecipesManage.Application.Services;
using RecipesManage.Domain.Batches;
using RecipesManage.Domain.Equipment;
using RecipesManage.Domain.Handshake;
using RecipesManage.Domain.Identity;
using RecipesManage.Domain.Recipes;
using RecipesManage.Infrastructure.Persistence;

namespace RecipesManage.Execution;

public sealed partial class BatchSchedulerHostedService
{
    private enum LaneResult { Completed, Held, Faulted }

    private sealed class WaveBarrier
    {
        private int _state;

        public void Signal(LaneResult result)
        {
            if (result is not (LaneResult.Held or LaneResult.Faulted))
                return;
            Interlocked.CompareExchange(ref _state, result == LaneResult.Held ? 1 : 2, 0);
        }

        public LaneResult? Peek() => Volatile.Read(ref _state) switch
        {
            1 => LaneResult.Held,
            2 => LaneResult.Faulted,
            _ => null
        };
    }

    private async Task RunUnitWavesAsync(Guid batchId, CancellationToken ct)
    {
        using var scope = _scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var batch = await db.Batches.Include(b => b.StepExecutions).FirstOrDefaultAsync(b => b.Id == batchId, ct)
                    ?? throw new InvalidOperationException("批次不存在");
        if (batch.Status is BatchStatus.Held or BatchStatus.Aborted or BatchStatus.Completed)
            return;

        var snapshot = BatchService.Deserialize(batch.ControlRecipeJson)
                       ?? throw new InvalidOperationException("快照损坏");
        var boundIds = UnitEquipmentBinding.AllIds(snapshot, batch.EquipmentId);
        var equipmentRows = await db.Equipment.Where(e => boundIds.Contains(e.Id)).ToListAsync(ct);
        if (equipmentRows.Count != boundIds.Count)
            throw new InvalidOperationException("批次绑定的设备缺失。");

        var plcs = new Dictionary<Guid, IPlcHandshakeClient>();
        var gate = new SemaphoreSlim(1, 1);
        try
        {
            foreach (var eq in equipmentRows)
            {
                var client = _drivers.Create(eq);
                await client.ConnectAsync(ct);
                plcs[eq.Id] = client;
            }

            batch.MarkRunning(DateTimeOffset.UtcNow);
            await db.SaveChangesAsync(ct);

            var waves = RecipeTopology.UnitProcedureWaves(
                snapshot.Steps.Select(s => (s.StepId, Isa88.UnitName(s.UnitProcedure))).ToList(),
                snapshot.Edges.Select(e => (e.FromStepId, e.ToStepId)).ToList());
            await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "isa88", new
            {
                waves,
                equipment = equipmentRows.Select(e => e.Code).ToList()
            }), ct);

            foreach (var wave in waves)
            {
                ct.ThrowIfCancellationRequested();
                var barrier = new WaveBarrier();
                var groups = wave
                    .GroupBy(unit => UnitEquipmentBinding.Resolve(snapshot, unit, batch.EquipmentId))
                    .ToList();
                var multiLane = plcs.Count > 1;
                var results = await Task.WhenAll(groups.Select(group => RunLaneAsync(
                    batchId, group.Key, group.ToList(), snapshot, db, batch, plcs, equipmentRows, gate, barrier, multiLane, ct)));
                if (results.Any(r => r is LaneResult.Held or LaneResult.Faulted) ||
                    barrier.Peek() is LaneResult.Held or LaneResult.Faulted)
                    return;
            }

            await LockedAsync(gate, ct, async () =>
            {
                batch.Complete(DateTimeOffset.UtcNow);
                await db.SaveChangesAsync(ct);
            });
            await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "completed", new { batch.BatchNo }), ct);
            await OccupancyRealtime.PublishAsync(db, _publisher, batch.Id, ct);
        }
        finally
        {
            foreach (var plc in plcs.Values)
                await plc.DisposeAsync();
            gate.Dispose();
        }
    }

    private async Task<LaneResult> RunLaneAsync(
        Guid batchId,
        Guid equipmentId,
        IReadOnlyList<string> units,
        ControlRecipeSnapshot snapshot,
        AppDbContext db,
        ProductionBatch batch,
        Dictionary<Guid, IPlcHandshakeClient> plcs,
        List<EquipmentLine> equipmentRows,
        SemaphoreSlim gate,
        WaveBarrier barrier,
        bool multiLane,
        CancellationToken hostCt)
    {
        var equipment = equipmentRows.Single(e => e.Id == equipmentId);
        var plc = plcs[equipmentId];
        var watchdog = HandshakeWatchdogOptions.FromJson(equipment.WatchdogJson);
        var firstOnPlc = true;
        foreach (var unit in units)
        {
            if (barrier.Peek() is { } stop)
            {
                await IdlePlcAsync(plc, hostCt);
                return stop;
            }

            var steps = snapshot.Steps
                .Where(s => string.Equals(Isa88.UnitName(s.UnitProcedure), unit, StringComparison.Ordinal))
                .ToList();
            SnapshotStep? last = null;
            HandshakeStateMachine? lastMachine = null;
            HandshakeWorkContext? lastWork = null;
            foreach (var step in steps)
            {
                var result = await RunPhaseAsync(
                    batchId, step, snapshot, db, batch, plc, equipment, watchdog, firstOnPlc, gate, barrier, multiLane, hostCt);
                firstOnPlc = false;
                if (result.Result != LaneResult.Completed)
                {
                    barrier.Signal(result.Result);
                    return result.Result;
                }

                if (barrier.Peek() is { } after)
                {
                    await IdlePlcAsync(plc, hostCt);
                    return after;
                }

                last = step;
                lastMachine = result.Machine;
                lastWork = result.Work;
            }

            if (last is not null && lastMachine is not null && lastWork is not null)
            {
                await LockedAsync(gate, hostCt, async () =>
                {
                    RecordHandshake(db, batch, last, lastMachine, lastWork, DateTimeOffset.UtcNow, "isa88",
                        $"Unit Procedure 完成：{unit}", equipment.Code);
                    await db.SaveChangesAsync(hostCt);
                });
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "isa88-unit-complete", new
                {
                    unitProcedure = unit,
                    stepCode = last.Code,
                    equipmentCode = equipment.Code
                }), hostCt);
            }
        }

        return LaneResult.Completed;
    }

    private sealed record PhaseOutcome(LaneResult Result, HandshakeStateMachine? Machine, HandshakeWorkContext? Work);

    private async Task<PhaseOutcome> RunPhaseAsync(
        Guid batchId,
        SnapshotStep step,
        ControlRecipeSnapshot snapshot,
        AppDbContext db,
        ProductionBatch batch,
        IPlcHandshakeClient plc,
        EquipmentLine equipment,
        HandshakeWatchdogOptions watchdog,
        bool resumeFromPlc,
        SemaphoreSlim gate,
        WaveBarrier barrier,
        bool multiLane,
        CancellationToken ct)
    {
        BatchStepExecution exec = null!;
        var alreadyDone = false;
        await LockedAsync(gate, ct, () =>
        {
            exec = batch.StepExecutions.Single(s => s.StepId == step.StepId);
            alreadyDone = exec.Outcome is "Completed" or "Skipped";
            return Task.CompletedTask;
        });
        if (alreadyDone)
            return new PhaseOutcome(LaneResult.Completed, null, null);

        var index = snapshot.Steps.ToList().FindIndex(s => s.StepId == step.StepId);
        var resumeHeld = false;
        var resumeCrashWait = false;
        await LockedAsync(gate, ct, async () =>
        {
            batch.AdvanceTo(step.StepId, Math.Max(index, 0));
            resumeCrashWait = exec.Outcome == "Running";
            if (exec.Outcome == "Held")
            {
                exec.ResumeFromHold();
                resumeHeld = true;
            }
            else
                exec.MarkStarted(DateTimeOffset.UtcNow);
            await db.SaveChangesAsync(ct);
        });

        if (step.Type == StepType.ManualConfirm)
            return await AwaitOperatorConfirmAsync(batchId, step, db, batch, plc, equipment, gate, barrier, multiLane, index, ct);

        if (step.Type is StepType.QualityCheck or StepType.Wait)
            return await RunHostSideStepAsync(batchId, step, db, batch, plc, equipment, gate, barrier, multiLane, index, resumeHeld, resumeCrashWait, ct);

        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "isa88", new
        {
            unitProcedure = step.UnitProcedure,
            operation = step.Operation,
            stepCode = step.Code,
            stepIndex = index,
            equipmentCode = equipment.Code
        }), ct);
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
        {
            stepId = step.StepId,
            stepIndex = index,
            outcome = "Running",
            unitProcedure = step.UnitProcedure,
            operation = step.Operation,
            equipmentCode = equipment.Code
        }), ct);

        var work = ControlRecipeWritePlan.ToWorkContext(step);

        var inbound0 = await plc.ReadSignalsAsync(ct);
        if (resumeHeld || inbound0.PlcHeld)
        {
            await ReleasePlcHoldAsync(plc, watchdog.HoldAckTimeout, ct);
            await LockedAsync(gate, ct, async () =>
            {
                db.HandshakeEvents.Add(new HandshakeEvent(
                    batch.Id, step.StepId, step.Code, "StepRunning", "resume",
                    $"[{equipment.Code}] Host_Hold=0", null));
                await db.SaveChangesAsync(ct);
            });
        }
        inbound0 = await plc.ReadSignalsAsync(ct);
        var resumeSession = resumeFromPlc || resumeHeld || inbound0.PlcHeld || inbound0.StepRunning || inbound0.StepComplete;
        var machine = resumeSession
            ? HandshakeStateMachine.ResumeFromPlc(inbound0, watchdog, DateTimeOffset.UtcNow)
            : new HandshakeStateMachine(watchdog, DateTimeOffset.UtcNow);
        if (machine.Phase is HandshakePhase.StepRunning or HandshakePhase.Completing or HandshakePhase.AwaitingPlcAck)
        {
            await LockedAsync(gate, ct, async () =>
            {
                RecordHandshake(db, batch, step, machine, work, DateTimeOffset.UtcNow, "resume",
                    "引擎恢复，从 PLC 当前握手相位继续，禁止重写参数", equipment.Code);
                await db.SaveChangesAsync(ct);
            });
        }
        var lastSampleAt = DateTimeOffset.MinValue;

        while (machine.Phase is not HandshakePhase.ReadyToAdvance)
        {
            ct.ThrowIfCancellationRequested();
            if (barrier.Peek() is { } peerStop)
            {
                if (peerStop == LaneResult.Held && machine.Phase == HandshakePhase.StepRunning)
                    await CommandPlcHoldAsync(plc, watchdog.HoldAckTimeout, ct);
                else
                    await IdlePlcAsync(plc, ct);
                if (peerStop == LaneResult.Held && machine.Phase == HandshakePhase.StepRunning)
                {
                    await LockedAsync(gate, ct, async () =>
                    {
                        exec.MarkHeld();
                        batch.UpdateLaneHandshake(equipment.Code, "Held", multiLane);
                        await db.SaveChangesAsync(ct);
                    });
                }

                return new PhaseOutcome(peerStop, machine, work);
            }

            if (machine.Phase == HandshakePhase.WaitingPlcReady &&
                TryConsumeSkip(batchId, step.StepId, out var skipReason))
            {
                await IdlePlcAsync(plc, ct);
                await LockedAsync(gate, ct, async () =>
                {
                    exec.MarkSkipped(skipReason);
                    RecordHandshake(db, batch, step, machine, work, DateTimeOffset.UtcNow, "skip", skipReason, equipment.Code);
                    await db.SaveChangesAsync(ct);
                });
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
                {
                    stepId = step.StepId, stepIndex = index, outcome = "Skipped"
                }), ct);
                return new PhaseOutcome(LaneResult.Completed, machine, work);
            }

            if ((machine.Phase is HandshakePhase.WaitingPlcReady or HandshakePhase.StepRunning) &&
                TryGetHold(batchId, out var holdReason))
            {
                var runningHold = machine.Phase == HandshakePhase.StepRunning;
                if (runningHold)
                    await CommandPlcHoldAsync(plc, watchdog.HoldAckTimeout, ct);
                else
                    await IdlePlcAsync(plc, ct);
                await LockedAsync(gate, ct, async () =>
                {
                    if (runningHold)
                        exec.MarkHeld();
                    else
                        exec.RevertToPending();
                    batch.UpdateLaneHandshake(equipment.Code, "Held", multiLane);
                    batch.Hold(holdReason);
                    ConsumeHold(batchId);
                    RecordHandshake(db, batch, step, machine, work, DateTimeOffset.UtcNow, "hold",
                        runningHold ? "Host_Hold=1 PLC_Held" : holdReason, equipment.Code);
                    await db.SaveChangesAsync(ct);
                });
                barrier.Signal(LaneResult.Held);
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "held", new
                {
                    reason = holdReason,
                    equipmentCode = equipment.Code,
                    hostHold = runningHold
                }), ct);
                return new PhaseOutcome(LaneResult.Held, machine, work);
            }

            var now = DateTimeOffset.UtcNow;
            var inbound = await plc.ReadSignalsAsync(ct);
            await LockedAsync(gate, ct, () =>
            {
                batch.UpdateLaneHandshake(equipment.Code, machine.Phase.ToString(), multiLane);
                return Task.CompletedTask;
            });

            if (now - lastSampleAt > TimeSpan.FromMilliseconds(400) &&
                machine.Phase is HandshakePhase.StepRunning or HandshakePhase.Completing)
            {
                var measured = await plc.ReadMeasuredAsync(ct);
                await LockedAsync(gate, ct, () =>
                {
                    foreach (var (tag, value) in measured)
                        db.ProcessSamples.Add(new ProcessSample(batch.Id, step.StepId, now, tag, value, null));
                    return Task.CompletedTask;
                });
                lastSampleAt = now;
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "sample", measured), ct);
            }

            await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "handshake", new
            {
                phase = machine.Phase.ToString(),
                status = batch.Status.ToString(),
                stepId = step.StepId,
                stepIndex = index,
                stepName = step.Name,
                remainingSeconds = machine.RemainingSeconds(work, now),
                inbound,
                equipmentCode = equipment.Code,
                unitProcedure = step.UnitProcedure,
                stepCode = step.Code
            }), ct);

            var phaseBefore = machine.Phase;
            var actions = machine.Tick(inbound, work, now);
            if (machine.Phase != phaseBefore)
            {
                await LockedAsync(gate, ct, () =>
                {
                    RecordHandshake(db, batch, step, machine, work, now, "phase", $"{phaseBefore}->{machine.Phase}", equipment.Code);
                    return Task.CompletedTask;
                });
            }

            foreach (var action in actions)
                await ApplyAsync(action, machine, plc, db, batch, exec, step, work, now, gate, equipment.Code, ct);

            if (exec.Outcome == "Completed")
            {
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
                {
                    stepId = step.StepId,
                    stepIndex = index,
                    outcome = "Completed",
                    qualityJson = exec.QualityJson
                }), ct);
            }

            if (machine.Phase == HandshakePhase.Faulted)
            {
                await LockedAsync(gate, ct, async () =>
                {
                    exec.MarkFaulted(machine.Fault?.Message ?? "握手故障");
                    batch.Fault(machine.Fault?.Code.ToString() ?? "FAULT", machine.Fault?.Message ?? "握手故障");
                    db.AuditLogs.Add(new AuditLog(null, "system", "batch.fault", "ProductionBatch", batch.Id.ToString(),
                        $"{machine.Fault?.Code}:{machine.Fault?.Message}"));
                    RecordHandshake(db, batch, step, machine, work, now, "fault", machine.Fault?.Message, equipment.Code);
                    db.ProcessAlarms.Add(new ProcessAlarm(
                        batch.Id, batch.BatchNo, step.StepId, step.Code,
                        machine.Fault?.Code.ToString() ?? "FAULT", "Fault",
                        machine.Fault?.Message ?? "握手故障", now));
                    await db.SaveChangesAsync(ct);
                });
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "fault", machine.Fault!), ct);
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "alarm", new
                {
                    code = machine.Fault?.Code.ToString(),
                    message = machine.Fault?.Message,
                    stepCode = step.Code
                }), ct);
                return new PhaseOutcome(LaneResult.Faulted, machine, work);
            }

            await LockedAsync(gate, ct, () => db.SaveChangesAsync(ct));
            await Task.Delay(100, ct);
        }

        if (exec.Outcome != "Skipped" && TryGetHold(batchId, out var holdAfter))
        {
            await IdlePlcAsync(plc, ct);
            await LockedAsync(gate, ct, async () =>
            {
                batch.UpdateLaneHandshake(equipment.Code, "Held", multiLane);
                batch.Hold(holdAfter);
                ConsumeHold(batchId);
                RecordHandshake(db, batch, step, machine, work, DateTimeOffset.UtcNow, "hold", holdAfter, equipment.Code);
                await db.SaveChangesAsync(ct);
            });
            barrier.Signal(LaneResult.Held);
            await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "held", new { reason = holdAfter, equipmentCode = equipment.Code }), ct);
            return new PhaseOutcome(LaneResult.Held, machine, work);
        }

        var oosHold = await HoldIfQualityOosAsync(
            step, exec, db, batch, plc, equipment, gate, barrier, multiLane, machine, work, ct);
        if (oosHold is not null)
            return oosHold;

        return new PhaseOutcome(LaneResult.Completed, machine, work);
    }

    private async Task<PhaseOutcome> RunHostSideStepAsync(
        Guid batchId,
        SnapshotStep step,
        AppDbContext db,
        ProductionBatch batch,
        IPlcHandshakeClient plc,
        EquipmentLine equipment,
        SemaphoreSlim gate,
        WaveBarrier barrier,
        bool multiLane,
        int index,
        bool resumeHeld,
        bool resumeCrashWait,
        CancellationToken ct)
    {
        await IdlePlcAsync(plc, ct);
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "isa88", new
        {
            unitProcedure = step.UnitProcedure,
            operation = step.Operation,
            stepCode = step.Code,
            stepIndex = index,
            equipmentCode = equipment.Code
        }), ct);
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
        {
            stepId = step.StepId,
            stepIndex = index,
            outcome = "Running",
            unitProcedure = step.UnitProcedure,
            operation = step.Operation,
            equipmentCode = equipment.Code
        }), ct);

        if (step.Type == StepType.Wait)
            return await AwaitHostWaitAsync(batchId, step, db, batch, plc, equipment, gate, barrier, multiLane, index, resumeHeld, resumeCrashWait, ct);

        IReadOnlyDictionary<string, double> measured = new Dictionary<string, double>();
        try
        {
            measured = await plc.ReadMeasuredAsync(ct);
        }
        catch
        {
            // 质检不依赖写 PLC；读不到实测时按设定值归档。
        }

        var bound = QualityArchive.Bind(step, measured);
        var quality = JsonSerializer.Serialize(bound, BatchService.JsonOptions);
        await LockedAsync(gate, ct, async () =>
        {
            var exec = batch.StepExecutions.Single(e => e.StepId == step.StepId);
            exec.MarkCompleted(DateTimeOffset.UtcNow, quality);
            batch.UpdateLaneHandshake(equipment.Code, "ReadyToAdvance", multiLane);
            db.HandshakeEvents.Add(new HandshakeEvent(
                batch.Id, step.StepId, step.Code, "ReadyToAdvance", "quality",
                $"[{equipment.Code}] 质检工步归档，禁止写 PLC", null));
            await db.SaveChangesAsync(ct);
        });
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
        {
            stepId = step.StepId,
            stepIndex = index,
            outcome = "Completed",
            qualityJson = quality
        }), ct);

        var after = batch.StepExecutions.Single(e => e.StepId == step.StepId);
        var oos = await HoldIfQualityOosAsync(
            step, after, db, batch, plc, equipment, gate, barrier, multiLane, null, null, ct);
        return oos ?? new PhaseOutcome(LaneResult.Completed, null, null);
    }

    private async Task<PhaseOutcome> AwaitHostWaitAsync(
        Guid batchId,
        SnapshotStep step,
        AppDbContext db,
        ProductionBatch batch,
        IPlcHandshakeClient plc,
        EquipmentLine equipment,
        SemaphoreSlim gate,
        WaveBarrier barrier,
        bool multiLane,
        int index,
        bool resumeHeld,
        bool resumeCrashWait,
        CancellationToken ct)
    {
        var planned = HostWaitClock.Planned(step);
        double? leftover = null;
        if (resumeHeld)
        {
            var holds = await db.HandshakeEvents
                .AsNoTracking()
                .Where(e => e.BatchId == batch.Id && e.StepId == step.StepId && e.Phase == "HostWait" && e.Kind == "hold")
                .ToListAsync(ct);
            leftover = holds
                .OrderByDescending(e => e.CreatedAt)
                .Select(e => e.RemainingSeconds)
                .FirstOrDefault();
        }
        else if (resumeCrashWait)
        {
            var waits = await db.HandshakeEvents
                .AsNoTracking()
                .Where(e => e.BatchId == batch.Id && e.StepId == step.StepId && e.Kind == "wait")
                .ToListAsync(ct);
            var lastWait = waits.OrderByDescending(e => e.CreatedAt).FirstOrDefault();
            if (lastWait is not null)
                leftover = HostWaitClock.LeftoverAfterInterrupt(
                    planned, lastWait.CreatedAt, lastWait.RemainingSeconds, DateTimeOffset.UtcNow).TotalSeconds;
        }
        var resume = resumeHeld || resumeCrashWait;
        var duration = HostWaitClock.Resolve(planned, resume, leftover);
        var deadline = DateTimeOffset.UtcNow + duration;
        await LockedAsync(gate, ct, async () =>
        {
            batch.UpdateLaneHandshake(equipment.Code, "HostWait", multiLane);
            var detail = resumeHeld
                ? $"[{equipment.Code}] 恢复等待剩余 {duration.TotalSeconds:0.##}s，禁止写 PLC"
                : resumeCrashWait
                    ? $"[{equipment.Code}] 引擎恢复等待剩余 {duration.TotalSeconds:0.##}s，禁止写 PLC"
                    : $"[{equipment.Code}] 等待 {duration.TotalSeconds:0.##}s，禁止写 PLC";
            db.HandshakeEvents.Add(new HandshakeEvent(
                batch.Id, step.StepId, step.Code, "HostWait", "wait",
                detail, duration.TotalSeconds));
            await db.SaveChangesAsync(ct);
        });

        while (!ct.IsCancellationRequested)
        {
            if (barrier.Peek() is { } peerStop)
            {
                await IdlePlcAsync(plc, ct);
                if (peerStop == LaneResult.Held)
                {
                    var remainingPeer = Math.Max(0, (deadline - DateTimeOffset.UtcNow).TotalSeconds);
                    await LockedAsync(gate, ct, async () =>
                    {
                        batch.StepExecutions.Single(e => e.StepId == step.StepId).MarkHeld();
                        batch.UpdateLaneHandshake(equipment.Code, "Held", multiLane);
                        db.HandshakeEvents.Add(new HandshakeEvent(
                            batch.Id, step.StepId, step.Code, "HostWait", "hold",
                            $"[{equipment.Code}] 邻道保持，保存等待剩余", remainingPeer));
                        await db.SaveChangesAsync(ct);
                    });
                }
                return new PhaseOutcome(peerStop, null, null);
            }

            if (TryConsumeSkip(batchId, step.StepId, out var skipReason))
            {
                await LockedAsync(gate, ct, async () =>
                {
                    batch.StepExecutions.Single(e => e.StepId == step.StepId).MarkSkipped(skipReason);
                    db.HandshakeEvents.Add(new HandshakeEvent(
                        batch.Id, step.StepId, step.Code, "HostWait", "skip",
                        $"[{equipment.Code}] {skipReason}", null));
                    await db.SaveChangesAsync(ct);
                });
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
                {
                    stepId = step.StepId, stepIndex = index, outcome = "Skipped"
                }), ct);
                return new PhaseOutcome(LaneResult.Completed, null, null);
            }

            if (TryGetHold(batchId, out var holdReason))
            {
                await IdlePlcAsync(plc, ct);
                var remainingHold = Math.Max(0, (deadline - DateTimeOffset.UtcNow).TotalSeconds);
                await LockedAsync(gate, ct, async () =>
                {
                    batch.StepExecutions.Single(e => e.StepId == step.StepId).MarkHeld();
                    batch.UpdateLaneHandshake(equipment.Code, "Held", multiLane);
                    batch.Hold(holdReason);
                    ConsumeHold(batchId);
                    db.HandshakeEvents.Add(new HandshakeEvent(
                        batch.Id, step.StepId, step.Code, "HostWait", "hold",
                        $"[{equipment.Code}] {holdReason}，剩余 {remainingHold:0.##}s", remainingHold));
                    await db.SaveChangesAsync(ct);
                });
                barrier.Signal(LaneResult.Held);
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "held", new { reason = holdReason, equipmentCode = equipment.Code }), ct);
                return new PhaseOutcome(LaneResult.Held, null, null);
            }

            var remaining = Math.Max(0, (deadline - DateTimeOffset.UtcNow).TotalSeconds);
            await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "handshake", new
            {
                phase = "HostWait",
                status = batch.Status.ToString(),
                stepId = step.StepId,
                stepIndex = index,
                stepName = step.Name,
                remainingSeconds = remaining,
                equipmentCode = equipment.Code,
                unitProcedure = step.UnitProcedure,
                stepCode = step.Code
            }), ct);

            if (remaining <= 0)
                break;

            await Task.Delay(120, ct);
        }

        await LockedAsync(gate, ct, async () =>
        {
            batch.StepExecutions.Single(e => e.StepId == step.StepId).MarkCompleted(DateTimeOffset.UtcNow, "{}");
            batch.UpdateLaneHandshake(equipment.Code, "ReadyToAdvance", multiLane);
            db.HandshakeEvents.Add(new HandshakeEvent(
                batch.Id, step.StepId, step.Code, "ReadyToAdvance", "wait",
                $"[{equipment.Code}] 等待完成，未写 PLC", null));
            await db.SaveChangesAsync(ct);
        });
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
        {
            stepId = step.StepId, stepIndex = index, outcome = "Completed"
        }), ct);
        return new PhaseOutcome(LaneResult.Completed, null, null);
    }

    private async Task<PhaseOutcome?> HoldIfQualityOosAsync(
        SnapshotStep step,
        BatchStepExecution exec,
        AppDbContext db,
        ProductionBatch batch,
        IPlcHandshakeClient plc,
        EquipmentLine equipment,
        SemaphoreSlim gate,
        WaveBarrier barrier,
        bool multiLane,
        HandshakeStateMachine? machine,
        HandshakeWorkContext? work,
        CancellationToken ct)
    {
        var oos = QualityArchive.EvaluateJson(step, exec.QualityJson).Where(r => r.OutOfSpec).ToList();
        if (oos.Count == 0)
            return null;

        var detail = string.Join("；", oos.Select(r => $"{r.Name}={r.Value:0.##} 规格[{r.Min},{r.Max}]"));
        await IdlePlcAsync(plc, ct);
        await LockedAsync(gate, ct, async () =>
        {
            batch.UpdateLaneHandshake(equipment.Code, "Held", multiLane);
            batch.Hold($"质检超差：{detail}");
            db.ProcessAlarms.Add(new ProcessAlarm(
                batch.Id, batch.BatchNo, step.StepId, step.Code,
                "QualityOos", "Quality", $"质检超差：{detail}", DateTimeOffset.UtcNow));
            if (machine is not null && work is not null)
                RecordHandshake(db, batch, step, machine, work, DateTimeOffset.UtcNow, "quality", $"超差 {detail}", equipment.Code);
            else
                db.HandshakeEvents.Add(new HandshakeEvent(
                    batch.Id, step.StepId, step.Code, "Held", "quality",
                    $"[{equipment.Code}] 超差 {detail}", null));
            await db.SaveChangesAsync(ct);
        });
        barrier.Signal(LaneResult.Held);
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "held", new { reason = $"质检超差：{detail}", equipmentCode = equipment.Code }), ct);
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "alarm", new
        {
            code = "QualityOos",
            message = $"质检超差：{detail}",
            stepCode = step.Code
        }), ct);
        return new PhaseOutcome(LaneResult.Held, machine, work);
    }

    private async Task<PhaseOutcome> AwaitOperatorConfirmAsync(
        Guid batchId,
        SnapshotStep step,
        AppDbContext db,
        ProductionBatch batch,
        IPlcHandshakeClient plc,
        EquipmentLine equipment,
        SemaphoreSlim gate,
        WaveBarrier barrier,
        bool multiLane,
        int index,
        CancellationToken ct)
    {
        await IdlePlcAsync(plc, ct);
        await LockedAsync(gate, ct, async () =>
        {
            execFrom(batch, step).MarkAwaitingConfirm();
            batch.UpdateLaneHandshake(equipment.Code, "AwaitingConfirm", multiLane);
            db.HandshakeEvents.Add(new HandshakeEvent(
                batch.Id, step.StepId, step.Code, "AwaitingConfirm", "confirm",
                $"[{equipment.Code}] 人工确认工步，禁止写 PLC", null));
            await db.SaveChangesAsync(ct);
        });
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
        {
            stepId = step.StepId,
            stepIndex = index,
            outcome = "AwaitingConfirm",
            unitProcedure = step.UnitProcedure,
            operation = step.Operation,
            equipmentCode = equipment.Code
        }), ct);
        await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "handshake", new
        {
            phase = "AwaitingConfirm",
            status = batch.Status.ToString(),
            stepId = step.StepId,
            stepIndex = index,
            stepName = step.Name,
            remainingSeconds = (double?)null,
            equipmentCode = equipment.Code,
            unitProcedure = step.UnitProcedure,
            stepCode = step.Code
        }), ct);

        while (!ct.IsCancellationRequested)
        {
            if (barrier.Peek() is { } peerStop)
            {
                await IdlePlcAsync(plc, ct);
                return new PhaseOutcome(peerStop, null, null);
            }

            if (TryConsumeSkip(batchId, step.StepId, out var skipReason))
            {
                await LockedAsync(gate, ct, async () =>
                {
                    execFrom(batch, step).MarkSkipped(skipReason);
                    db.HandshakeEvents.Add(new HandshakeEvent(
                        batch.Id, step.StepId, step.Code, "AwaitingConfirm", "skip",
                        $"[{equipment.Code}] {skipReason}", null));
                    await db.SaveChangesAsync(ct);
                });
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
                {
                    stepId = step.StepId, stepIndex = index, outcome = "Skipped"
                }), ct);
                return new PhaseOutcome(LaneResult.Completed, null, null);
            }

            if (TryGetHold(batchId, out var holdReason))
            {
                await IdlePlcAsync(plc, ct);
                await LockedAsync(gate, ct, async () =>
                {
                    execFrom(batch, step).MarkHeld();
                    batch.UpdateLaneHandshake(equipment.Code, "Held", multiLane);
                    batch.Hold(holdReason);
                    ConsumeHold(batchId);
                    db.HandshakeEvents.Add(new HandshakeEvent(
                        batch.Id, step.StepId, step.Code, "AwaitingConfirm", "hold",
                        $"[{equipment.Code}] {holdReason}", null));
                    await db.SaveChangesAsync(ct);
                });
                barrier.Signal(LaneResult.Held);
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "held", new { reason = holdReason, equipmentCode = equipment.Code }), ct);
                return new PhaseOutcome(LaneResult.Held, null, null);
            }

            if (TryConsumeConfirm(batchId, step.StepId, out var comment))
            {
                var quality = JsonSerializer.Serialize(new Dictionary<string, string>
                {
                    ["确认"] = "通过",
                    ["意见"] = string.IsNullOrWhiteSpace(comment) ? "操作员确认" : comment
                }, BatchService.JsonOptions);
                await LockedAsync(gate, ct, async () =>
                {
                    execFrom(batch, step).MarkCompleted(DateTimeOffset.UtcNow, quality);
                    db.HandshakeEvents.Add(new HandshakeEvent(
                        batch.Id, step.StepId, step.Code, "ReadyToAdvance", "confirm",
                        $"[{equipment.Code}] 人工确认完成，未写 PLC", null));
                    await db.SaveChangesAsync(ct);
                });
                await _publisher.PublishAsync(new ExecutionEvent(batch.Id, "step", new
                {
                    stepId = step.StepId, stepIndex = index, outcome = "Completed", qualityJson = quality
                }), ct);
                return new PhaseOutcome(LaneResult.Completed, null, null);
            }

            await Task.Delay(120, ct);
        }

        return new PhaseOutcome(LaneResult.Faulted, null, null);

        static BatchStepExecution execFrom(ProductionBatch b, SnapshotStep s) =>
            b.StepExecutions.Single(e => e.StepId == s.StepId);
    }

    private bool TryGetHold(Guid batchId, out string reason) =>
        _holdReasons.TryGetValue(batchId, out reason!);

    private void ConsumeHold(Guid batchId) => _holdReasons.TryRemove(batchId, out _);

    private static async Task CommandPlcHoldAsync(IPlcHandshakeClient plc, TimeSpan timeout, CancellationToken ct)
    {
        await plc.SetHostHoldAsync(true, ct);
        var deadline = DateTime.UtcNow + timeout;
        PlcInboundSignals signals;
        do
        {
            ct.ThrowIfCancellationRequested();
            signals = await plc.ReadSignalsAsync(ct);
            if (signals.PlcHeld)
                return;
            await Task.Delay(80, ct);
        } while (DateTime.UtcNow < deadline);

        throw new InvalidOperationException("PLC 未在时限内以 PLC_Held 应答 Host_Hold。");
    }

    private static async Task ReleasePlcHoldAsync(IPlcHandshakeClient plc, TimeSpan timeout, CancellationToken ct)
    {
        await plc.SetHostHoldAsync(false, ct);
        var deadline = DateTime.UtcNow + timeout;
        PlcInboundSignals signals;
        do
        {
            ct.ThrowIfCancellationRequested();
            signals = await plc.ReadSignalsAsync(ct);
            if (!signals.PlcHeld)
                return;
            await Task.Delay(80, ct);
        } while (DateTime.UtcNow < deadline);
    }

    private static async Task LockedAsync(SemaphoreSlim gate, CancellationToken ct, Func<Task> work)
    {
        await gate.WaitAsync(ct);
        try
        {
            await work();
        }
        finally
        {
            gate.Release();
        }
    }
}
