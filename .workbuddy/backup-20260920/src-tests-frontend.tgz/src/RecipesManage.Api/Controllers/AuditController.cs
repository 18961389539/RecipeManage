using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RecipesManage.Application.Dtos;
using RecipesManage.Application.Services;

namespace RecipesManage.Api.Controllers;

[Authorize]
[ApiController]
[Route("api/audit")]
public sealed class AuditController(AuditService audit) : ControllerBase
{
    [HttpGet]
    public Task<IReadOnlyList<AuditLogDto>> Query(
        [FromQuery] string? entityType,
        [FromQuery] string? entityId,
        [FromQuery] int take = 200,
        CancellationToken ct = default) =>
        audit.QueryAsync(entityType, entityId, take, ct);
}
