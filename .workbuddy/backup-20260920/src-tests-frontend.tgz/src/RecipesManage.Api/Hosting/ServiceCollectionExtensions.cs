using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using RecipesManage.Api.Hubs;
using RecipesManage.Application.Contracts;
using RecipesManage.Application.Services;
using RecipesManage.Domain.Identity;
using RecipesManage.Execution;
using RecipesManage.Infrastructure.Persistence;
using RecipesManage.Infrastructure.Plc;
using RecipesManage.Infrastructure.Records;

namespace RecipesManage.Api;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddRecipesManage(this IServiceCollection services, IConfiguration config, IWebHostEnvironment env)
    {
        services.AddDbContext<AppDbContext>(options =>
        {
            RecipesDatabase.Apply(options, config.GetConnectionString("PostgreSQL"), config.GetConnectionString("Sqlite"));
            options.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll);
        });

        services.AddScoped<IAppDbContext>(sp => sp.GetRequiredService<AppDbContext>());
        services.AddSingleton<IPasswordHasher, BcryptPasswordHasher>();
        services.AddScoped<ICurrentUser, HttpCurrentUser>();
        services.AddScoped<AuthService>();
        services.AddScoped<RecipeService>();
        services.AddScoped<MaterialLotService>();
        services.AddScoped<BatchService>();
        services.AddScoped<EquipmentService>();
        services.AddScoped<AuditService>();
        services.AddSingleton<SimulatedPlcRack>();
        services.AddSingleton<ModbusTcpHandshakeSlave>();
        services.AddHostedService<ModbusLoopbackHostedService>();
        services.AddSingleton<OpcUaHandshakeSlave>();
        services.AddHostedService<OpcUaLoopbackHostedService>();
        services.AddSingleton<SiemensS7HandshakeSlave>();
        services.AddHostedService<SiemensS7LoopbackHostedService>();
        services.AddSingleton<IPlcDriverFactory, PlcDriverFactory>();
        services.AddSingleton<IBatchRecordPdf, BatchRecordPdf>();
        services.AddSingleton<BatchSchedulerHostedService>();
        services.AddSingleton<IBatchScheduler>(sp => sp.GetRequiredService<BatchSchedulerHostedService>());
        services.AddHostedService(sp => sp.GetRequiredService<BatchSchedulerHostedService>());
        services.AddSignalR();
        services.AddSingleton<IExecutionPublisher, SignalRExecutionPublisher>();

        var jwtKey = config["Jwt:Key"] ?? "dev-only-change-me-32bytes-minimum-key!!";
        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = config["Jwt:Issuer"] ?? "RecipesManage",
                    ValidAudience = config["Jwt:Audience"] ?? "RecipesManage",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
                };
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        var accessToken = context.Request.Query["access_token"];
                        if (!string.IsNullOrEmpty(accessToken) &&
                            context.HttpContext.Request.Path.StartsWithSegments("/hubs"))
                        {
                            context.Token = accessToken;
                        }
                        return Task.CompletedTask;
                    }
                };
            });
        services.AddAuthorization();
        return services;
    }
}

public sealed class HttpCurrentUser : ICurrentUser
{
    private readonly IHttpContextAccessor _accessor;
    public HttpCurrentUser(IHttpContextAccessor accessor) => _accessor = accessor;

    private ClaimsPrincipal? Principal => _accessor.HttpContext?.User;
    public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated == true;
    public Guid? UserId => Guid.TryParse(Principal?.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : null;
    public string UserName => Principal?.Identity?.Name ?? "";
    public string DisplayName => Principal?.FindFirstValue("displayName") ?? UserName;
    public UserRole? Role => Enum.TryParse<UserRole>(Principal?.FindFirstValue(ClaimTypes.Role), out var role) ? role : null;
}

public static class JwtIssuer
{
    public static string Issue(IConfiguration config, Domain.Identity.AppUser user)
    {
        var key = config["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key missing");
        var creds = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)), SecurityAlgorithms.HmacSha256);
        var hours = double.TryParse(config["Jwt:ExpireHours"], out var h) ? h : 12;
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.UserName),
            new Claim("displayName", user.DisplayName),
            new Claim(ClaimTypes.Role, user.Role.ToString())
        };
        var token = new JwtSecurityToken(
            config["Jwt:Issuer"] ?? "RecipesManage",
            config["Jwt:Audience"] ?? "RecipesManage",
            claims,
            expires: DateTime.UtcNow.AddHours(hours),
            signingCredentials: creds);
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
